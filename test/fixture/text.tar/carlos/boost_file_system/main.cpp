#include "boost/filesystem.hpp"
#include <string>
#include <iostream>

using namespace boost::filesystem;
using namespace std;

int main(int argc, char* argv[]) {
  string path(argv[1]);

  if (is_directory(path)) {
    for (directory_iterator itr(path); itr!=directory_iterator(); ++itr) {
      cout << itr->path().filename() << ' '; // display filename only
      if (is_regular_file(itr->status())) cout << " [" << file_size(itr->path()) << ']';
      cout << '\n';
    }
  }

  return 0;
} 
