#ifndef __gamma_h__
#define __gamma_h__

void gamma_encode(int number, int* gamma_value, int* gamma_len );

void gamma_decode(int number);

#endif /* __gamma_h__ */
