#include <stdio.h>
#include "unary.h"
#include "gamma.h"
#include "delta.h"
#include "test_coders.h"
#include "tool.h"

#define BUFFER_SIZE 32

void buffer_add(char* buffer, int* offset, int value, int len){
  int bitoffset = *offset % 8;
  int charoffset = *offset / 8;
  value = value << ( (sizeof(value)*8)-len-bitoffset) ;
  buffer[charoffset] |= value;
  *offset += len;
}

int main(int argc, char* argv[]) {
/*
  printf("unary_encode\n");
  test_encode(2,9, unary_encode);
  printf("gama_encode\n");
  test_encode(12,19, gamma_encode);
  printf("delta_encode\n");
  test_encode(12,19, delta_encode);
  printf("unary_decode\n");
  test_unary_decode();
*/

  

  return 0;
}
