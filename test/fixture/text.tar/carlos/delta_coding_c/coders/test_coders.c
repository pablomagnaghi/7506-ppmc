#include <stdio.h>
#include "unary.h"
#include "gamma.h"
#include "delta.h"
#include "tool.h"

void test_unary_decode() {
  int unary_value;
  int unary_len;

  for (int i=1; i < 12 ; ++i) {
    unary_encode(i,&unary_value, &unary_len);
    printf("%2d", i);
    binary_show(unary_value, unary_len);
    printf("  %2d\n", unary_decode(unary_value));
  }
}

void test_encode(int start, int stop,void (*f)(int,int*,int*)) {
  int value = 0;
  int len   = 0;

  for (int i=start; i<stop; ++i){
    f(i,&value, &len);
    printf("%4d", i);
    binary_show(value, len);
    printf("\n");
  }

}

