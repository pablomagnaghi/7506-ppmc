#ifndef __tool_h__
#define __tool_h__

void binary_show(int value, int len);

void buffer_add(char* buffer, int* offset, int value, int len);

#define BUFFER_SIZE 32

#endif /* __tool_h__ */
