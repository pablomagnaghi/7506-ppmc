#ifndef __unary_h__
#define __unary_h__

void unary_encode(int number, int* unary_value, int* len);

int unary_decode(int number);

#endif /* __unary_h__ */

