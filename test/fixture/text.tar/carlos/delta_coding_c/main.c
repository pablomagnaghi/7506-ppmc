/*
El objetivo de este ejercicio es no perder memoria tras crear N objetos,
guardar las referencias con delta coding y eliminar las referencias originales


*/

#define SIZE 10 
#define MAX_RND_BURST 100 

#include <malloc.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct node {
   void* original_ptr;
};

void nodes_sort(struct node* nodes[SIZE], int size) {
  for(int i=0; i<size -1 ; ++i) {
    for (int j= i; j < size; ++j) {
      if (nodes[i] > nodes[j]){
        struct node * tmp = nodes[i];
        nodes[i] = nodes[j];
        nodes[j] = tmp;
      }
    }
  }
}

void nodes_print(struct node* nodes[SIZE], int size) {
  for (int i=0; i<size; ++i) {
     printf("%3d : %08x\n",i, &(*nodes[i])/* nodes[i]->original_ptr*/);
  }
}

void nodes_load(struct node* nodes[SIZE]){
  struct node* fill[SIZE*MAX_RND_BURST];
  int fillcount = 0;
  for(int i=0; i < SIZE; ++i){
    nodes[i]=(struct node*) malloc(sizeof(struct node));
    nodes[i]->original_ptr=nodes[i];
    int burst = rand() % MAX_RND_BURST;
    printf("burst %d\n", burst);
    for (int j=0; j < burst ; ++j) {
      fill[fillcount]=(struct node*) malloc(sizeof(struct node));
      fill[fillcount]->original_ptr=fill[fillcount];
      ++fillcount;
    }
  }
  for (int i=0; i < fillcount; ++i) {
    free(fill[i]);
  }
}

int delta_encode(char* deltas,  int* offset, void* ptr1, void* ptr2) {
  int distance = (int*)ptr2-(int*)ptr1;
  int delta = distance;
  deltas[*offset]= delta;

  printf("ptr1: %08x ptr2: %08x dist: %4d offset: %4d\n", (unsigned int)ptr1, (unsigned int)ptr2, distance, *offset);
  *offset+=sizeof(distance);

  return 0;
}

int delta_decode(/* const char* deltas[SIZE],*/ int offset, void** ptr) {


  return 0;
}
void delta_print() {


}
int main(int argc, char* argv[]) {
  srand((int)&argc);
  char deltas[SIZE];
  struct node* nodes[SIZE];
  nodes_load(nodes);  
  nodes_sort(nodes, SIZE);
  printf("Imprimiendo nodos\n");
  nodes_print(nodes, SIZE);
  
  int offset=0;
  for (int i=0; i< SIZE -1; ++i){
    delta_encode(deltas, &offset, &(*nodes[i]), &(*nodes[i+1]));

  }
  //memset(&nodes, 0, SIZE);

  //

  for (int i=0; i < SIZE; ++i) {
    free(nodes[i]);

  }


   return 0;
}
