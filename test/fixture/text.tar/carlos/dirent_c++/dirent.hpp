#ifndef __dirent_hpp__
#define __dirent_hpp__

#include <string>
#include <exception>

namespace dirent {

#include <dirent.h>

# undef DT_UNKNOWN
# undef DT_BLK
# undef DT_CHR
# undef DT_DIR
# undef DT_FIFO
# undef DT_LNK
# undef DT_REG
# undef DT_SOCK


/*
estos valores estan puestos a mano, segun /dev
*/

# define DT_UNKNOWN 0
# define DT_BLK     6 
# define DT_CHR     2
# define DT_DIR     4 
# define DT_FIFO    1
# define DT_LNK     10
# define DT_REG     8
# define DT_SOCK    12 

class DirentException:public std::exception {
public:
  DirentException(const std::string msg2);
  virtual const char* what() const throw();
private:
  const std::string& msg;
};


class Dirent {
public:
  Dirent(const std::string& path2) throw(DirentException);
  Dirent(const char* path2) throw(DirentException);
  ~Dirent();

private:
  DIR * dir;
  std::string path;
  void open_error(int last_error)throw(DirentException){
};


}

/* 
 * Concatena dos nombres, separandolos con "/"
 * Es necesario liberar la memoria.
 */
//char* build_next_object(char* base, char* object);

/*
 * Abre un directorio para recorrer, mostrando por stderr cualquier error
 * y devolviendo el estado de error
 */
//int wrap_opendir(DIR ** dir, char* dirname);


/*
 * Devuelve en un char* la ruta completa hasta la raiz de un archivo o 
 * directorio
 * Es necesario liberar la memoria.
 */
//char* full_path(DIR * dir, char* base);

/*
 * Muestra informacion del directorio
 *
 */
//void dir_dump_info(DIR * dir);

/*
 * Recorre el contenido de un directorio mostrandolo por stderr y hace
 * rewind
 */
//void dir_dump(DIR * dir);

#endif /* __dirent_hpp__ */
