using namespace std;
using namespace dirent;


DirentException::DirentException(const std::string msg2):msg(msg2){}

const char* DirentException::what() const throw() {
    return msg.c_str();
  }

