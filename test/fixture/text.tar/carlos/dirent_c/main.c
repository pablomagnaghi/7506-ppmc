#include <stdio.h>

#include "wrap_dirent.h"

int main(int argc, char* argv[]) {
  DIR * dir;
  int last_error = wrap_opendir(&dir, argv[1]);
  if (last_error){
    return last_error;
  }

  dir_dump(dir);
  dir_dump_info(dir);

  closedir(dir);
  return 0;
}


