/*#include <sys/types.h>*/

#include "wrap_dirent.h"

#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>

char* build_next_object(char* base, char* object) {
  int size_of_base   = strlen(base);
  int size_of_object = strlen(object);
  int size_of_next_object = size_of_base + size_of_object + 2;
  char * next_object = (char*) malloc(size_of_next_object );
  memset(next_object, 0, size_of_next_object);
  strncpy(next_object, base, size_of_base);
  strncpy(&next_object[size_of_base],"/", 1);
  strncpy(&next_object[size_of_base + 1], object, size_of_object);
  return next_object;
}

int wrap_opendir(DIR ** dir, char* dirname) {
  *dir = opendir(dirname);
  int last_error=errno;
  if (*dir) {
    return 0;
  }
  if (last_error) {
    fprintf(stderr, "%s: ", dirname);
  }

  switch (last_error) {
    case EACCES:  fprintf(stderr, "Permission denied.\n");
      break;
    case EBADF:   fprintf(stderr, "fd is not a valid file descriptor opened for reading.\n");
      break;
    case EMFILE:  fprintf(stderr, "Too many file descriptors in use by process.\n");
      break;
    case ENFILE:  fprintf(stderr, "Too many files are currently open in the system.\n");
      break;
    case ENOENT:  fprintf(stderr, "Directory does not exist, or name is an empty string.\n");
      break;
    case ENOMEM:  fprintf(stderr, "Insufficient memory to complete the operation.\n");
      break;
    case ENOTDIR: fprintf(stderr, "name is not a directory.\n");
      break;
  }
  return last_error;
}

char* full_path(DIR * dir, char* base){
  // abrir el directorio
  // abrir ..
  // obtener el nombre

  if (strlen(base) == 0) {

  } else {

  }
  
return 0;
}

void dir_dump_info(DIR * dir) {
  struct dirent * entry = 0;
  int found = 0;
  int inode;
  while ( ( entry = readdir(dir) ) ) {
    if ( ! strcmp(entry->d_name, ".")) {
      fprintf(stderr, "%30s\n", entry->d_name);
      fprintf(stderr, "%10d\n", (int) entry->d_ino);
      inode = (int) entry->d_ino;
      found = 1;
            
    }
  }
  if (!found) {
    return;
  }
  rewinddir(dir);
  while ( ( entry = readdir(dir) ) ) {
    if ( ! strcmp(entry->d_name, "..")) {
      fprintf(stderr, "%30s\n", entry->d_name);
      fprintf(stderr, "%10d\n", (int) entry->d_ino);
      found = 1;

    }
  }
  if (!found) {
    return;
  }

//  DIR * parent = opendir(
}

void dir_dump(DIR * dir){
  struct dirent * entry = 0;
  while ( ( entry = readdir(dir) ) ) {
    fprintf(stderr, "%30s : %2d : ", entry->d_name, entry->d_type);
    switch(entry->d_type) {
       case DT_BLK:      fprintf(stderr, "block device.\n"); break;
       case DT_CHR:      fprintf(stderr, "character device.\n"); break;
       case DT_DIR:      fprintf(stderr, "directory.\n"); break;
       case DT_FIFO:     fprintf(stderr, "fifo.\n"); break;
       case DT_LNK:      fprintf(stderr, "symbolic link.\n"); break;
       case DT_REG:      fprintf(stderr, "regular file.\n"); break;
       case DT_SOCK:     fprintf(stderr, "Unix domain socket.\n"); break;
       case DT_UNKNOWN:  fprintf(stderr, "unknown.\n"); break;
       default:          fprintf(stderr, "indefinido.\n"); break;
    }
  }
  rewinddir(dir);
}

