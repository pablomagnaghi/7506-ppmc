#include "inotifywatch.hpp"
using namespace std;
using namespace inotify;


InotifyException::InotifyException(const std::string msg2):msg(msg2){}

const char* InotifyException::what() const throw() {
    return msg.c_str();
  }

