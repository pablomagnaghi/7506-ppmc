#include "inotifywatch.hpp"
#include "../container/container.hpp"

/*
           IN_ACCESS         File was accessed (read) (*).
           IN_ATTRIB         Metadata changed, e.g., permissions, timestamps, extended attributes, link count (since Linux 2.6.25), UID, GID, etc. (*).
           IN_CLOSE_WRITE    File opened for writing was closed (*).
           IN_CLOSE_NOWRITE  File not opened for writing was closed (*).
           IN_CREATE         File/directory created in watched directory (*).
           IN_DELETE         File/directory deleted from watched directory (*).
           IN_DELETE_SELF    Watched file/directory was itself deleted.
           IN_MODIFY         File was modified (*).
           IN_MOVE_SELF      Watched file/directory was itself moved.
           IN_MOVED_FROM     File moved out of watched directory (*).
           IN_MOVED_TO       File moved into watched directory (*).
           IN_OPEN
*/
using namespace inotify;

int main(int argc, char* argv[]){
  Container watches;

  InotifyWatch watch(watches);

  watch.add("/home/charly/.catalog/config.ini", IN_CLOSE_WRITE | IN_DELETE_SELF | IN_MODIFY | IN_MOVED_FROM | IN_MOVED_TO);

  watch.add(argv[1], IN_CREATE | IN_DELETE | IN_DELETE_SELF | IN_MODIFY | IN_MOVED_FROM | IN_MOVED_TO);
while (1)
  watch.read();
  return 0;
}

