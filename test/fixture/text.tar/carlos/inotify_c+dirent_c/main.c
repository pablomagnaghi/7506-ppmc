#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <errno.h>
#include <unistd.h>
#include "../dirent/wrap_dirent.h"
#include "../inotify/wrap_inotify.h"

// @todo pasar al header correspondiente
#define IN_WRITE_EVENTS   IN_ACCESS | IN_CLOSE_WRITE | IN_CREATE | IN_DELETE | IN_DELETE_SELF | IN_MODIFY | IN_MOVE_SELF | IN_MOVED_FROM | IN_MOVED_TO


// @todo pasar al source correspondiente

int validate(const char * name) {
  char * extension[] = {".txt", ".pdf", ".jpg", ".png", ".mp3", ".c", ".py"};
  for (int i=0; i<sizeof(*extension) - 1 ; ++i) {
    if ( 0==strcmp(extension[i], &name[strlen(name)-strlen(extension[i])])) {
      return 1;
    }
  }
  return 0;


}

int recursive_wrap_inotify_add_watch(int* watch, int ifd, char* object, int events) {
  struct dirent * entry = 0;
  int result = 1;
  DIR * dir;
  fprintf(stderr, "%s ", object);
  // si no se puede abrir como directorio, no nos interesa
  if ( wrap_opendir(&dir, object)) {
    fprintf(stderr,"no es directorio\n");
    closedir(dir);
    return 1;
  }

  // no hay recursion sobre . o .. a menos que sea el primero
  if ( ! strcmp(&object[strlen(object)-1] , ".") /* && strlen(object) > 2*/) {
    fprintf(stderr," omitiendo recursion\n");
    closedir(dir);
    return 1;
  }

  // agregamos watch por que es un directorio
  result = wrap_inotify_add_watch(watch, ifd, object, events); // falta evaluar si ok
  if (!result) {
     fprintf(stderr," WATCHING\n");
  }


  while ( ( entry = readdir(dir) ) ) {
    switch(entry->d_type) {
      case DT_DIR: {
        char * next_object = build_next_object(object, entry->d_name);
        result = recursive_wrap_inotify_add_watch( watch, ifd, next_object, events);
        free(next_object);
        break;
      }
      case DT_LNK: {
        //break;
        fprintf(stderr, "  symbolic link %s\n", object);
        char * next_object = build_next_object(object, entry->d_name);
        // intentamos verlo como directorio 
        result = recursive_wrap_inotify_add_watch( watch, ifd, next_object, events);
        // si no es directorio, lo indexamos
        if (!result && validate(next_object)) {
          fprintf(stderr,"  regular file, %s INDEXING\n",  next_object);
        }
        free(next_object);
        break;
      }
      case DT_REG: {
        char * next_object = build_next_object(object, entry->d_name);
        if (validate(next_object)) {
          fprintf(stderr,"  regular file, %s INDEXING\n",  next_object);
        }
        free(next_object);
        break;
      }
      case DT_BLK:
      case DT_CHR:
      case DT_FIFO:
      case DT_SOCK:
      case DT_UNKNOWN:
      default:
        break;
    }
  }
  closedir(dir);
  return result;
}

# define MAX_EVENT_BUFFER_SIZE 512

int monitor(int watch, int ifd, char* folder) {
  char event_buffer[MAX_EVENT_BUFFER_SIZE];
  struct inotify_event* event = (struct inotify_event*) event_buffer;
  int event_count = 0;
  int last_error  = 0;
  while (1 || event_count ) {
    int modified = 0;
    fprintf(stdout,"monitoreando");
    int size = read(ifd, event, sizeof(event_buffer));
    if (size == EINVAL ) {
      fprintf(stderr," Read EINVAL\n");
    } else if (0 && event->wd != watch) {
      fprintf(stderr," no es para mi\n");
    } else {
      if (event->mask & IN_CLOSE_WRITE) {
        fprintf(stderr,"IN_CLOSE_WRITE %d =  ",IN_CLOSE_WRITE);
        modified=1;
      }
      if (event->mask & IN_CREATE) {
        fprintf(stderr,"IN_CREATE %d = ", IN_CREATE) ;
        modified=1;
      }
      if (event->mask & IN_DELETE) { 
        fprintf(stderr,"IN_DELETE %d = ", IN_DELETE) ;
        modified=1;
      }
      if (event->mask & IN_DELETE_SELF) {
        fprintf(stderr,"IN_DELETE_SELF %d = ", IN_DELETE_SELF) ;
        modified=1;
      }
      if (event->mask & IN_MODIFY) {
        fprintf(stderr,"IN_MODIFY %d = ", IN_MODIFY);
        modified=1;
      }
      if (event->mask & IN_MOVE_SELF) {
        fprintf(stderr,"IN_MOVE_SELF %d =  ", IN_MOVE_SELF);
        modified=1;
      }
      if (event->mask & IN_MOVED_FROM) {
        fprintf(stderr,"IN_MOVED_FROM %d = ", IN_MOVED_FROM) ;
        modified=1;
      }
      if (event->mask & IN_MOVED_TO) {
        fprintf(stderr,"IN_MOVED_TO %d = ", IN_MOVED_TO) ;
        modified=1;
      }
      if (modified && event->mask & IN_ISDIR) { 
        fprintf(stderr,"XX IN_ISDIR\n");
        // remontar la estructura de directorios hasta la raiz o el punto de root watch
        // y asi contruir el nombre completo
        //
        // recursive_wrap_inotify_add_watch(&watch, ifd, argv[1], IN_ALL_EVENTS);

        // vvvvvvvvvv WARNING vvvvvvvvvv
        // todo este bloque es incorrecto, no abre el directorio deseado sino el root de monitoreo
        DIR * dir;
        last_error = wrap_opendir(&dir, folder);
        if (last_error){
          return last_error;
        }
        dir_dump(dir);

        closedir(dir);
        // ^^^^^^^^^^ END WARNING ^^^^^^^^^^
      } else if (modified) {
        // remontar la estructura de directorios hasta la raiz o el punto de root watch
        // y asi contruir el nombre completo
        fprintf(stderr, " INDEXAR o REINDEXAR %s\n", event->name);

      } else {
        fprintf(stderr, " sin modificación\n");
      }
      if (event->mask & IN_Q_OVERFLOW) fprintf(stderr,"XX IN_Q_OVERFLOW\n");
      if (event->mask & IN_UNMOUNT) fprintf(stderr,"XX_IN_UNMOUNT\n"); 

      if (event->len > 0) {
         fprintf(stdout,"evento sobre %s\n", event->name);
      }
      ++event_count;
    }
  }
  return last_error;
}

int main(int argc, char* argv[]){
  int watch;
  int last_error;
  int ifd;

  last_error = wrap_inotify_init(&ifd);
  if (last_error) {
    return last_error;
  }

  last_error = recursive_wrap_inotify_add_watch(&watch, ifd, argv[1], IN_WRITE_EVENTS);

  if (!last_error) {
    return last_error;
  }

  last_error= monitor(watch, ifd, argv[1]);

  close(ifd);

  return last_error;
}



