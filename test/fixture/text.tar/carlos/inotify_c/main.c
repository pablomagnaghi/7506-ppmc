#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

#include "wrap_inotify.h"


int main(int argc, char* argv[]){
  int watch;
  int last_error;
  int ifd;

  last_error = wrap_inotify_init(&ifd);
  if (last_error) {
    return last_error;
  }

  last_error = wrap_inotify_add_watch(&watch, ifd, argv[1], IN_ALL_EVENTS);

  if (last_error) {
    return last_error;
  }

  char event_buffer[512];
  struct inotify_event* event = (struct inotify_event*) event_buffer;

  int size = 1;
  while (1) {
    size = read(ifd, event, sizeof(event_buffer));
    if (size == EINVAL ) {
      printf("Read EINVAL");
    } else if (event->wd != watch) {
      printf(".");
    } else {
      if (event->mask & IN_ATTRIB) printf("IN_ATTRIB %d = " , IN_ATTRIB);
      if (event->mask & IN_CLOSE_WRITE) printf("IN_CLOSE_WRITE %d =  ",IN_CLOSE_WRITE);
      if (event->mask & IN_CLOSE_NOWRITE) printf("IN_CLOSE_NOWRITE %d = ", IN_CLOSE_NOWRITE) ;
      if (event->mask & IN_CREATE) printf("IN_CREATE %d = ", IN_CREATE) ;
      if (event->mask & IN_DELETE) printf("IN_DELETE %d = ", IN_DELETE) ;
      if (event->mask & IN_DELETE_SELF) printf("IN_DELETE_SELF %d = ", IN_DELETE_SELF) ;
      if (event->mask & IN_MODIFY) printf("IN_MODIFY %d = ", IN_MODIFY);
      if (event->mask & IN_MOVE_SELF) printf("IN_MOVE_SELF %d =  ", IN_MOVE_SELF);
      if (event->mask & IN_MOVED_FROM) printf("IN_MOVED_FROM %d = ", IN_MOVED_FROM) ;
      if (event->mask & IN_MOVED_TO) printf("IN_MOVED_TO %d = ", IN_MOVED_TO) ;
      if (event->mask & IN_OPEN) printf("IN_OPEN %d = ", IN_OPEN) ;
      printf("\n");
      if (event->mask & IN_IGNORED) printf("XX IN_IGNORED\n");
      if (event->mask & IN_ISDIR) printf("XX IN_ISDIR\n");
      if (event->mask & IN_Q_OVERFLOW) printf("XX IN_Q_OVERFLOW\n");
      if (event->mask & IN_UNMOUNT) printf("XX_IN_UNMOUNT\n"); 

      if (event->len > 0) {
         printf("evento sobre %s", event->name);
      }
      //sleep(1);
    }
  }
  close(ifd);

  return 0;
}

