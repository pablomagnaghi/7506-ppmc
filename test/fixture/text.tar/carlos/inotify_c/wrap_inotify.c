
#include <errno.h>
/*#include <unistd.h>*/
#include <stdio.h>
#include "wrap_inotify.h"


int wrap_inotify_init(int * ifd) {
  int last_error;
  *ifd = inotify_init();
  last_error = errno;
  if (*ifd != -1) {
    return 0;
  }

  switch (last_error) {
    case EINVAL:  fprintf(stderr, "An invalid value was specified in flags.\n");
      break;
    case EMFILE:  fprintf(stderr, "The user limit on the total number of inotify instances has been reached.\n");
      break;
    case ENFILE:  fprintf(stderr, "The system limit on the total number of file descriptors has been reached.\n");
      break;
    case ENOMEM:  fprintf(stderr, "Insufficient kernel memory is available.\n");;
      break;
  }
  return last_error;
}

int wrap_inotify_add_watch(int* watch, int ifd, char* object, int events) {
  int last_error;
  *watch = inotify_add_watch(ifd, object, events);
  last_error= errno;
  if (*watch != -1) {
    return 0;
  }
  switch (last_error)  {
    case EACCES: fprintf(stderr, "Read access to the given file is not permitted.\n");
      break;
    case EBADF:  fprintf(stderr, "The given file descriptor is not valid.\n");
      break;
    case EFAULT: fprintf(stderr, "pathname points outside of the process's accessible address space.\n");
      break;
    case EINVAL: fprintf(stderr, "The given event mask contains no valid events; or fd is not an inotify file descriptor.\n");
      break;
    case ENOMEM: fprintf(stderr, "Insufficient kernel memory was available.\n");
      break;
    case ENOSPC: fprintf(stderr, "The user limit on the total number of inotify watches was reached or the kernel failed to allocate a needed resource\n");
      break;
  }
  return last_error;
}

