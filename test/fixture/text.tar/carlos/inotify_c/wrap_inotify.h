#ifndef __wrap_inotify_h__
#define __wrap_inotify_h__

#include <sys/inotify.h>

int wrap_inotify_init(int * ifd);

int wrap_inotify_add_watch(int* watch, int ifd, char* object, int events);

#endif /* __wrap_inotify_h__ */

