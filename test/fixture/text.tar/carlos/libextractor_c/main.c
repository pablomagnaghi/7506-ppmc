#include <extractor.h>
#include <stdio.h>

/* 

Para ejecutar:
export LD_PATH=/usr/lib/libextractor

libextractor_mpeg
libextractor_exiv2
libextractor_ole2
libextractor_ogg
libextractor_flac
libextractor_qt
libextractor_html
libextractor_man
libextractor_ps
libextractor_pdf
libextractor_mp3
libextractor_id32
libextractor_id3v23
libextractor_id3v24
libextractor_mime
libextractor_tar
libextractor_dvi
libextractor_deb
libextractor_png
libextractor_gif
libextractor_wav
libextractor_flv
libextractor_real
libextractor_jpeg
libextractor_tiff
libextractor_zip
libextractor_rpm
libextractor_riff
libextractor_applefile
libextractor_elf
libextractor_oo
libextractor_asf
libextractor_sid
libextractor_nsfe
libextractor_nsf
libextractor_it
libextractor_xm
libextractor_s3m

version: 336384

*/


int main(int argc, char* argv[]) {
  if (argc != 2) {
     printf("Este programa recibe un y solo un argumento\n");
     return 1;
  }

  EXTRACTOR_ExtractorList * plugins = 0;
  EXTRACTOR_KeywordList   * tags = 0;
  int count=0;

//  plugins = EXTRACTOR_loadDefaultLibraries();
  plugins = EXTRACTOR_addLibrary(plugins, "libextractor_png");
  plugins = EXTRACTOR_addLibrary(plugins, "libextractor_mp3");
  plugins = EXTRACTOR_addLibrary(plugins, "libextractor_id3v2");
  plugins = EXTRACTOR_addLibrary(plugins, "libextractor_id3v23");
  plugins = EXTRACTOR_addLibrary(plugins, "libextractor_id3v24");
  plugins = EXTRACTOR_addLibrary(plugins, "libextractor_jpeg");
  plugins = EXTRACTOR_addLibraryLast(plugins, "libextractor_pdf");


  if (! plugins) {
    fprintf(stderr, "Revise que se pueda acceder a los plugins en LD_LIBRARY_PATH\n");
    fprintf(stderr, "export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/lib64/libextractor\n");
    fprintf(stderr, "Esta es la lista de plugins disponibles %s\n", EXTRACTOR_DEFAULT_LIBRARIES);
    return 2;
  }

  tags = EXTRACTOR_getKeywords(plugins, argv[1]);


  count = EXTRACTOR_countKeywords(tags);


  if (!count) {
    printf("%s no tiene metadata\n", argv[1]);
  } else {

//  tags = EXTRACTOR_removeDuplicateKeywords(tags, EXTRACTOR_DUPLICATES_REMOVE_UNKNOWN;CTOR_KeywordList   * tags = 0;

    printf("Impresion de la libreria para %s\n", argv[1]);

    EXTRACTOR_printKeywords(stdout, tags);


    EXTRACTOR_KeywordList   * cursor = tags;

   printf("\nImpresion de la aplicacion para %s\n", argv[1]);
    while (cursor) {
      printf( "keyword: %s type: %d\n",cursor->keyword , cursor->keywordType);
      cursor = cursor->next;
    }

    EXTRACTOR_freeKeywords(tags);
  }

  EXTRACTOR_removeAll(plugins); /* unload plugins */

  printf("\n");
  return 0;
}

