./run /home/opt/ut/q3ut4/screenshots/shot0000.jpg
./run /store/musica/clasificado/p/PJ\ Harvey/PJ\ Harvey\ -\ Uh\ Huh\ Her\ \[2004\]/08.\ Cat\ On\ The\ Wall.mp3
./run /home/charly/Desktop/personal/fiuba/7506/_admin/calendario_2_2009.pdf
./run /home/charly/ropero.png
./run main.cpp
