#include <iostream>
#include <string>
#include "ngramer.hpp"

using namespace std;

int main(int argc, char* argv[]) {
  NGramer ng;
  ng.init();
  for (int j=2; j< argc; ++j) {
    string test = argv[j];
    cout << "loading " << test << endl;
    ng.load(test, j);
  }
  ng.dump();

  string query = argv[1];
  vector< NGramSearchResult > result = ng.search(query);

  for (unsigned int j=0; j< result.size(); ++j) {
    cout << result[j].ngram.first << result[j].ngram.second << " ";
    for (unsigned int i=0; i < result[j].ngramcell.list.size(); ++i) {
      cout << argv[result[j].ngramcell.list[i]] << " ";
    }
    cout << endl;
  }


  return 0;
}
