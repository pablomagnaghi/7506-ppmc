#include "ngramer.hpp"

#include <iostream>
using namespace std;

void NGramer::init(){
  NGramCell c;
  c.count=0;
  for (int i=0; i < SIZE; ++i) {
    m.push_back(vector< NGramCell >());
    for (int j=0; j < SIZE; ++j) {
      m[i].push_back(c);
    }
  }
}

void NGramer::load(const std::string& word, int code) {
  string test(word); 
  vector< NGram> result =  split(test);

  for (unsigned int i=0; i< result.size(); ++i){
    m[result[i].first][result[i].second].count++;
    m[result[i].first][result[i].second].list.push_back(code);
  }
}

NGramCell NGramer::getCell(const NGram& ngram) {
  return m[ngram.first][ngram.second];
}

std::vector< NGram > NGramer::split(const std::string& word) {
  vector<NGram> result;
  NGram n;
  n.first=0x2f;
  n.second=word[0];
  result.push_back(n);
  unsigned int i;
  for (i=0; i<word.size() - 1; ++i) {
    n.first=word[i];
    n.second=word[i+1];
    result.push_back(n);
  }

  n.first=word[i];
  n.second=0x2f;
  result.push_back(n);
  return result;
}

std::vector< NGramSearchResult > NGramer::search(const std::string& query) {
  vector< NGramSearchResult > result;
  vector< NGram > all = split(query);
  for (unsigned int i = 0; i< all.size(); ++i){
    NGramSearchResult row;
    row.ngram=all[i];
    if (all[i].first!='*' && all[i].first!='?' && all[i].second!='*' && all[i].second!='?') {
      row.ngramcell=getCell(all[i]);
    
      result.push_back(row);
    }
  }
  return result;
}

void NGramer::dump(){
  unsigned int min = 47; //@todo hardcoded
  unsigned int max = 92; //@todo hardcoded
  cout << " ";
  for (unsigned int i = min; i < max; ++i) {
    cout.width(2);
    cout << char(i);
  }
  cout << endl;
  for (unsigned int i = min; i < max; ++i){
    cout << char(i) ;
    for (unsigned int j = min; j < max; ++j) {
      cout.width(2);
      if (m[i][j].count) {
        if (m[i][j].count > 0xff) {
          cout << " *";
        } else {
          cout << hex << m[i][j].count;
        }
      } else {
        cout << ".";
      }
    }
    cout << " " << char(i) << endl;
  }
  cout << " ";
  for (unsigned int i = min; i < max; ++i) {
    cout.width(2);
    cout << char(i);
  }
  cout << endl << endl;
}
