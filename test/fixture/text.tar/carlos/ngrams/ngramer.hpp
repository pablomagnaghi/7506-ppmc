#ifndef __ngramer_hpp__
#define __ngramer_hpp__

#include <vector>
#include <string>


#define SIZE 256 //@todo buscar un modo mas elegante...

struct NGram {
  char first;
  char second;
};

struct NGramCell {
  int count; // si queda vector, este se va pues existe vector.size()
  std::vector< int > list; // @todo validar esta estructura, probablemente reemplazar
};

struct NGramSearchResult {
  NGram ngram;
  NGramCell ngramcell;
};

class NGramer {
public:
  /*
   * Carga cada palabra
   */
  void load(const std::string& word, int code);

  /*
   *
   */
  NGramCell getCell(const NGram& ngram);

  /*
   * Parte una palabra en bigramas
   */
  std::vector< NGram > split(const std::string& word);

  /*
   * Crea la grilla vacia
   * @todo evaluar pasar al constructor
   */
  void init();

  /*
   * Devuelve los codigos de las palabras que cumplen por bigrama
   */
  std::vector < NGramSearchResult > search(const std::string& query); 

  /*
   * Muestra la grilla
   */
  void dump();

private:
  std::vector< std:: vector < NGramCell  > > m;

};

#endif /* __ngramer_hpp__ */
