#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "constantes.h"
#include "registro.h"

/* devuelve el tamanio de un campo en bytes */
int sizeofField(int tipo, int cant) {
  tipo &= ~UNSIGNED;
  switch(tipo) {
    case CHAR: return sizeof(char) * cant; // cant es valido solo para char.
    case INT : return sizeof(int);
    case LONG: return sizeof(long);
    case FLOAT:return sizeof(float);
    case DOUBLE: return sizeof(double);
    default : return 0;
  }
  return 0;
}
// devuelve el tamanio en bytes de un registro con esquemauema esquema.
int REG_SIZEOF(const campo *esquema){
  int size=0;
  if( !esquema ) return 0;
   // suma todos los tamanios.
  while (esquema->nombre) {
   size+=sizeofField(esquema->tipo,esquema->longitud);
   ++esquema;
  }
  return size;
}

// rellena el bufferfer con los valores de los campos especificados.
int REG_SET(const void *buffer, const campo *esquema, int campos, ... ){
  va_list marker;
  int    offset=0;
  if( !buffer || !esquema || campos < 1 )
    return RES_ERROR;
  va_start(marker,campos);
  offset = 0;
  for (int i=0; i< campos; ++i){
    int tipo = esquema[i].tipo & ~UNSIGNED;
    switch(tipo) {
      case INT:     *(int   *)((char*)buffer+offset) = va_arg(marker, int );break;
      case LONG:    *(long *)((char*)buffer+offset) = va_arg(marker, long);break;
      case FLOAT: *(float *)((char*)buffer+offset) = (float)va_arg(marker, double);break;
      case DOUBLE: *(double*)((char*)buffer+offset) = va_arg(marker, double);break;
      case CHAR: {
        char* strfield = va_arg(marker,char*);
        int len  = strlen(strfield);
        if( len > esquema[i].longitud ) len = esquema[i].longitud;
        memcpy((char*)buffer+offset,strfield,len*sizeof(char));
        memset((char*)buffer+offset+len,0,1);
        break;
      }
      default: return RES_ERROR;
    }
 offset+=sizeofField(esquema[i].tipo,esquema[i].longitud);
  }
  va_end(marker);
  return RES_OK;
}
// obtiene los valores del bufferfer y los guarda en las variables especificadas.
int REG_GET(const void *buffer, const campo *esquema, int campos, ... ){
  va_list marker;
  int    offset =0;
  if( !buffer || !esquema || campos < 1 ) return RES_ERROR;
  va_start(marker,campos);
  for (int i=0; i<campos;++i){
    memcpy(va_arg(marker,void *),
      (const char*)buffer+offset,
      sizeofField(esquema[i].tipo,esquema[i].longitud));
    offset+=sizeofField(esquema[i].tipo,esquema[i].longitud);

  }
  va_end(marker);
  return RES_OK;
}
