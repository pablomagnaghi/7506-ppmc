#ifndef __constantes_hpp__
#define __constantes_hpp__

/* valores con signo. */

#define CHAR     1
#define INT      2
#define LONG     3
#define FLOAT    4
#define DOUBLE   5
#define UNSIGNED 0x80 

#define   READ                    1
#define   WRITE                   2
#define   READ_WRITE              3 // READ | WRITE
#define   APPEND                  4

#define   RES_OK                  0     //La primitiva se ejecutó con  éxito
#define   RES_NULL               -1     //No se pudo abrir el archivo
#define   RES_ERROR              -2     //Se produjo un error
#define   RES_EOF                -3     //Fin de Archivo
#define   RES_EXISTE             -4     //El registro/archivo ya existe
#define   RES_NO_EXISTE          -5     //El registro no existe
#define   RES_EXISTE_INDICE      -6     //El índice ya existe
#define   RES_NO_ EXISTE_INDICE  -7     //El índice no existe
#define   RES_ARCHIVO_LLENO      -8     //El archivo directo está lleno
#define   RES_ES_PRIM            -9     //El índice que se intenta eliminar es el principal

/*
enum tipos {
  CHAR     = 1,
  INT      = 2,
  LONG     = 3,
  FLOAT    = 4,
  DOUBLE   = 5,
  UNSIGNED = 0x80

};

enum operacion {
  READ       = 1,
  WRITE      = 2,
  READ_WRITE = READ | WRITE,
  APPEND     = 4
};


enum resultados {
  RES_OK                 =  0, //La primitiva se ejecutó con  éxito
  RES_NULL               = -1, //No se pudo abrir el archivo
  RES_ERROR              = -2, //Se produjo un error
  RES_EOF                = -3, //Fin de Archivo
  RES_EXISTE             = -4, //El registro/archivo ya existe
  RES_NO_EXISTE          = -5, //El registro no existe
  RES_EXISTE_INDICE      = -6, //El indice ya existe
  RES_NO_EXISTE_INDICE   = -7, //El indice no existe
  RES_ARCHIVO_LLENO      = -8, //El archivo directo está lleno
  RES_ES_PRIM            = -9  //El índice que se intenta eliminar es el principal
};
*/

#endif /* __constantes_hpp__ */
