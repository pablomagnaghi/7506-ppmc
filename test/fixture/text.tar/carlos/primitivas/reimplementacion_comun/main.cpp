#include <cstdio>
#include <cstring>
#include "constantes.hpp"
#include "registro.hpp"

int main(int argc, char* argv[]) {
  campo esquema[]={
    {"Padron", LONG, 1},
    {"DNI", LONG, 1},
    {"Nombre", CHAR, 20},
    {0,0,0}
  };
  
  int size = REG_SIZEOF(esquema);
  printf("size %d %d \n",size, sizeof(esquema));
  char * buffer = new char[size];
  
  memset(buffer,0,size);

  long padron=87000;
  long dni=31003423;
  char nombre[20];
  strncpy(nombre,"Romina Sunchales\0",20);
  long dni2=0;
  long padron2=0;
  char nombre2[20];

  if( REG_SET(buffer, esquema, 3, padron, dni,nombre) ) {
    printf("REG SET ERROR\n");
    delete[]( buffer);
    return 1;
  }
  printf("Padron:  %ld\n",padron);
  printf("Dni:     %ld\n",dni);
  printf("Nombre:  %s\n",nombre);

  printf("REG SET OK\n");
  
  if( REG_GET(buffer, esquema,3 , &padron2, &dni2, &nombre2) ) {
    printf("REG GET ERROR\n");
    delete[](buffer);
    return 2;
  }
  printf("REG GET OK\n");

  printf("Padron:  %ld\n",padron2);
  printf("Dni:     %ld\n",dni2);
  printf("Nombre:  %s\n",nombre2);
  delete[](buffer);
  return 0;
}

