#ifndef __registro_hpp__
#define __registro_hpp__

typedef struct {
   const char* nombre;
   int tipo;
   int longitud;
} campo;


int sizeofField(int tipo, int cant);
int REG_SIZEOF(const campo *esq);
int REG_SET(const void *buf, const campo *esq, int campos, ... );
int REG_GET(const void *buf, const campo *esq, int campos, ... );

#endif /* __registro_hpp__ */
