#include <malloc.h>
#include <stdio.h>
#include <string.h>

#include "relativa.h"
#include "../comun/constantes.h"
#include "../comun/registro.h"


int main(int argc, char* argv[]) {
  campo esquema[] = { {"nombre" ,CHAR, 20}, {"edad" ,INT ,1 } , {"",0,0}};
  int size=REG_SIZEOF(esquema);
  void * reg = malloc(size);
  if (reg == 0) {
    fprintf(stderr, "falla malloc\n");
    return RES_ERROR;
  }
  int status = R_CREATE(argv[1],size,5);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo crear\n");
    return status;
  }
  int fh = R_OPEN(argv[1], WRITE);

  if (fh == 0) {
    fprintf(stderr, "no se pudo abrir\n");
    return RES_ERROR;
  }
  if (fh < 0) {
    fprintf(stderr, "no se pudo abrir\n");
    return status;
  }

  // alice 
  status = REG_SET(reg, esquema, 2, "alice", 1);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo cargar registro\n");
    return status;
  }

  status = R_WRITE(fh, 1, reg);  

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo grabar\n");
    return status;
  }

  // bob
  status = REG_SET(reg, esquema, 2, "bob", 2);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo cargar registro\n");
    return status;
  }

  status = R_WRITE(fh, 2, reg);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo grabar\n");
    return status;
  }

  // cher
  status = REG_SET(reg, esquema, 2, "cher", 3);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo cargar registro\n");
    return status;
  }

  status = R_WRITE(fh, 3, reg);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo grabar\n");
    return status;
  }


  status = R_CLOSE(fh);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo cerrar\n");
    return status;
  }

  printf("Fin escritura\n");

  fh = R_OPEN(argv[1], READ);

  if (fh == 0) {
    fprintf(stderr, "no se pudo abrir\n");
    return RES_ERROR;
  }
  char* nombre[20];
  int edad;
  for (int i=0; i<5; ++i){  
   
    status = R_READ(fh, i, reg);
    if (status == RES_NO_EXISTE) {
      printf("No existe registro %d\n", i);
    } else {
      if (status != RES_OK) {
        fprintf(stderr, "no se pudo leer\n");
        return status;
      }
      status =  REG_GET(reg, esquema, 2, nombre, &edad);
      printf("nombre %s edad %d\n", *nombre, edad);
   }

  }

  free(reg);
  return 0;
}
