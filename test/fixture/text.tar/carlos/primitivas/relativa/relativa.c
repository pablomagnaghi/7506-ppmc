#include <stdio.h>
#include "relativa.h"
#include "../comun/constantes.h"

struct header {
  int tam_reg;
  int max_reg;
  int actual;
};

int R_READHEADER( FILE* fh, struct header* encabezado) {
  if (1 != fread(&encabezado->tam_reg, 4,1,fh)
     && 1 != fread(&encabezado->max_reg,4,1,fh)
     && 1 != fread(&encabezado->actual,4,1,fh) ) {
    return RES_ERROR;
  }
  return RES_OK;
}

int R_WRITEHEADER( FILE* fh, struct header* encabezado) {
  if (1 != fwrite(&encabezado->tam_reg, 4,1,fh)
     && 1 != fwrite(&encabezado->max_reg,4,1,fh)
     && 1 != fwrite(&encabezado->actual,4,1,fh) ) {
    return RES_ERROR;
  }
  return RES_OK;
}

int R_CREATE(const char* nombre_fisico, int tam_registro, int max_reg){
  FILE * fh = fopen(nombre_fisico, "w"); // esta truncando?
  if (!fh) {
    return RES_ERROR;
  }

  struct header encabezado;
  encabezado.tam_reg = tam_registro;
  encabezado.max_reg = max_reg,
  encabezado.actual = 0;

  if ( RES_OK != R_WRITEHEADER(fh, &encabezado)) {
    return RES_ERROR;
  }

  // podriamos llenarlo ya, no?
  if (fclose(fh)) {
    return RES_ERROR;
  }
  return RES_OK;
}

int R_OPEN(const char* nombre_fisico, int modo){
  FILE* fh = fopen(nombre_fisico,"rw");
  if (!fh) {
    return RES_ERROR;
  }
  
  return (int) fh;
}

int R_CLOSE(int handler){
  if(!handler || fclose((FILE*) handler)){
    return RES_ERROR;
  }
  return RES_OK;
}

int R_SEEK(int handler, int n_reg){
  if(!handler){
    return RES_ERROR;
  }

  struct header encabezado;
  if ( RES_OK != R_READHEADER((FILE*)handler, &encabezado)) {
    return RES_ERROR;
  } 

  if (n_reg >= encabezado.max_reg) {
    return RES_NO_EXISTE;
  }
 
  int posicion=n_reg * encabezado.tam_reg + 12;
 
  if (-1 == fseek((FILE*)handler,posicion, SEEK_SET)) {
    return RES_ERROR;
  }

  encabezado.actual = n_nreg;

  if ( RES_OK != R_WRITEHEADER(fh, &encabezado)) {
    return RES_ERROR;
  }

  return RES_OK;
}

int R_READ(int handler, int n_reg, void* reg){
  if(!handler){
    return RES_ERROR;
  }
  return RES_OK;
}

int R_READNEXT(int handler, void* reg){
  if(!handler){
    return RES_ERROR;
  }
  // leer de encabezado posicion actual

  return RES_OK;
}

int R_WRITE(int handler, int n_reg, const void* reg){
  if(!handler){
    return RES_ERROR;
  }
  return RES_OK;
}

int R_UPDATE(int handler, int n_reg, const void* reg){
  if(!handler){
    return RES_ERROR;
  }
  return RES_OK;
}

int R_DELETE(int handler, int n_reg){
  if(!handler){
    return RES_ERROR;
  }
  return RES_OK;
}

int R_DESTROY(const char* nombre_fisico){
  return RES_OK;
}

int R_GETMAXREGS(int handler){
  if(!handler){
    return RES_ERROR;
  }

  struct header encabezado;
  if ( RES_OK != R_READHEADER((FILE*)handler, &encabezado)) {
    return RES_ERROR;
  }
  
  return RES_OK;
}

