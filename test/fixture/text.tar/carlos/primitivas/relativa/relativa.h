#ifndef __relativo_h__
#define __relativo_h__

#include "../comun/constantes.h"

int R_CREATE(const char* nombre_fisico, int tam_registro, int max_reg);

int R_OPEN(const char* nombre_fisico, int modo);

int R_CLOSE(int handler);

int R_SEEK(int handler, int n_reg);

int R_READ(int handler, int n_reg, void* reg);

int R_READNEXT(int handler, void* reg);

int R_WRITE(int handler, int n_reg, const void* reg);

int R_UPDATE(int handler, int n_reg, const void* reg);

int R_DELETE(int handler, int n_reg);

int R_DESTROY(const char* nombre_fisico);

int R_GETMAXREGS(int handler);


#endif /* __relativo_h__ */
