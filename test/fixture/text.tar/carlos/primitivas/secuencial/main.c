#include <malloc.h>
#include <stdio.h>
#include <string.h>

#include "secuencial.h"
#include "../comun/constantes.h"
#include "../comun/registro.h"


int main(int argc, char* argv[]) {
  campo esquema[] = { {"nombre" ,CHAR, 20}, {"edad" ,INT ,1 } , {"",0,0}};
  int size=REG_SIZEOF(esquema);
  void * reg = malloc(size);
  if (reg == 0) {
    fprintf(stderr, "falla malloc\n");
    return RES_ERROR;
  }
  int status = S_CREATE(argv[1]);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo crear\n");
    return status;
  }
  int fh = S_OPEN(argv[1], WRITE);

  if (fh == 0) {
    fprintf(stderr, "no se pudo abrir\n");
    return RES_ERROR;
  }
  if (fh < 0) {
    fprintf(stderr, "no se pudo abrir\n");
    return status;
  }

  // alice 
  status = REG_SET(reg, esquema, 2, "alice", 1);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo cargar registro\n");
    return status;
  }

  status = S_WRITE(fh, reg, size);  

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo grabar\n");
    return status;
  }

  // bob
  status = REG_SET(reg, esquema, 2, "bob", 2);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo cargar registro\n");
    return status;
  }

  status = S_WRITE(fh, reg, size);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo grabar\n");
    return status;
  }

  // cher
  status = REG_SET(reg, esquema, 2, "cher", 3);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo cargar registro\n");
    return status;
  }

  status = S_WRITE(fh, reg, size);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo grabar\n");
    return status;
  }


  status = S_CLOSE(fh);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo cerrar\n");
    return status;
  }

  printf("Fin escritura\n");

  fh = S_OPEN(argv[1], READ);

  if (fh == 0) {
    fprintf(stderr, "no se pudo abrir\n");
    return RES_ERROR;
  }
  int salir = 0;
  char* nombre[20];
  int edad;
  while( !salir ) {
   
    status = S_READ(fh, reg);
    if (status == RES_EOF) {
      printf("Fin de archivo\n");
      salir = 1;
    } else {
      if (status != RES_OK) {
        fprintf(stderr, "no se pudo leer\n");
        return status;
      }
      status =  REG_GET(reg, esquema, 2, nombre, &edad);
      printf("nombre %s edad %d\n", nombre, edad);
   }

  }

  free(reg);
  return 0;
}
