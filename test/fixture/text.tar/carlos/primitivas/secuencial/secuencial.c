#include "secuencial.h"
#include "../comun/constantes.h"

#include <stdio.h>

int S_CREATE(const char* nombre_fisico) {
  int status = RES_ERROR;
  // if exists return RES_EXISTE;
  // create or int status = RES_ERROR; return status;;
 status = RES_OK; 
  return status;
}

int S_OPEN(const char* nombre_fisico, int modo) {
  int status = RES_ERROR;
  FILE * fh;
  switch (modo) {

    case READ: {
      // abrir y posicionarse al comienzo
      fh = fopen(nombre_fisico,"r");
      break;
    }
    case WRITE: {
      // abrir y posicionarse al comienzo
      fh = fopen(nombre_fisico,"w");
      break;
    }
    case APPEND: {
      // abrir y posicionarse al final
      fh = fopen(nombre_fisico, "a");
      break;
    }
  }
  if (fh == 0) {
    status = RES_ERROR;
  } else {
    status = (int) fh;
  }

  return status;
}

int S_READ(int handler, void* reg) {
  if (! handler || ! reg) {
    return RES_ERROR;
  }

  if( feof((FILE*) handler)) {
    return RES_EOF;
  }


  unsigned long cantidad;
  if (1 != fread(&cantidad, sizeof(cantidad), 1, (FILE*)handler)) {
    if( feof((FILE*) handler)) {
      return RES_EOF;
    } 

    return RES_ERROR;
  }
  printf("cantidad %d\n", cantidad);
  if (1 != fread(reg,cantidad,1,(FILE*)handler)) {
    return RES_ERROR;
  }



  return RES_OK;
}

int S_CLOSE(int handler){
  if (!handler || fclose((FILE*)handler)) {
    return RES_ERROR;
  }
  return RES_OK;
}


int S_WRITE(int handler, const void* reg, unsigned long cantidad) {
  if (!handler ) {
    return RES_ERROR;
  }


  if (1 != fwrite(&cantidad,sizeof(cantidad),1,(FILE*)handler)) {
    return RES_ERROR;
  }

  if (1 != fwrite(reg,cantidad,1,(FILE*)handler)) {
    return RES_ERROR;
  }

  return RES_OK;
}

int S_DESTROY(const char* nombre_fisico) {
  int status = RES_ERROR;
  return status;
}

