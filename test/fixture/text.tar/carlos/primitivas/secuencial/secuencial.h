#ifndef __secuencial_h__
#define __secuencial_h__

#include "../comun/constantes.h"

int S_CREATE(const char* nombre_fisico);

int S_OPEN(const char* nombre_fisico, int modo);

int S_READ(int handler, void* reg);

int S_CLOSE(int handler);

int S_WRITE(int handler, const void* reg, unsigned long cantidad);

int S_DESTROY(const char* nombre_fisico);

#endif /* __secuencial_h__ */
