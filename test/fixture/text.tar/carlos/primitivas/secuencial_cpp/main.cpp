#include <cstdio>

#include "secuencial.hpp"
#include "../comun_cpp/constantes.hpp"
#include "../comun_cpp/registro.hpp"

int main(int argc, char* argv[]) {
  campo esquema[] = { {"nombre" ,CHAR, 20}, {"edad" ,INT ,1 } , {"",0,0}};
  int size=REG_SIZEOF(esquema);
  char * reg = new char(size);
  FILE* fh;
  if (reg == 0) {
    fprintf(stderr, "falla malloc\n");
    return RES_ERROR;
  }
  int status = S_CREATE(argv[1]);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo crear\n");
    return status;
  }
  status = S_OPEN(argv[1], WRITE, &fh);

  if (status == 0) {
    fprintf(stderr, "no se pudo abrir\n");
    return RES_ERROR;
  }
  if (fh < 0) {
    fprintf(stderr, "no se pudo abrir\n");
    return status;
  }

  status = REG_SET(reg, esquema, 2, "pedro");

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo cargar registro\n");
    return status;
  }

  status = S_WRITE(fh, reg, 1);  

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo grabar\n");
    return status;
  }

  status = REG_SET(reg, esquema, 2, "pablo", 3);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo cargar registro\n");
    return status;
  }

  status = S_WRITE(fh, reg, 1);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo grabar\n");
    return status;
  }

  status = S_CLOSE(fh);

  if (status != RES_OK) {
    fprintf(stderr, "no se pudo cerrar\n");
    return status;
  }

  status = S_OPEN(argv[1], READ, &fh);

  if (status == 0) {
    fprintf(stderr, "no se pudo abrir\n");
    return RES_ERROR;
  }

  while( 1 ) {
    


  }

  delete(reg);
  return 0;
}
