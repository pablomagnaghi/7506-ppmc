#include "secuencial.hpp"
#include "../comun_cpp/constantes.hpp"

#include <cstdio>


int S_CREATE(const char* nombre_fisico) {
  int status = RES_ERROR;
  // if exists return RES_EXISTE;
  // create or int status = RES_ERROR; return status;;
  
  return status;
}

int S_OPEN(const char* nombre_fisico, int modo, FILE** fh) {
  int status = RES_ERROR;
  switch (modo) {

    case READ: {
      // abrir y posicionarse al comienzo
      *fh = fopen(nombre_fisico,"r");
      break;
    }
    case WRITE: {
      // abrir y posicionarse al comienzo
      *fh = fopen(nombre_fisico,"w");
      break;
    }
    case APPEND: {
      // abrir y posicionarse al final
      *fh = fopen(nombre_fisico, "a");
      break;
    }
  }
  if (*fh == 0) {
    status = RES_ERROR;
  }

  return status;
}

int S_READ(FILE* handler, void* reg) {
  int status = RES_ERROR;
  return status;
}

int S_CLOSE(FILE* handler){
  int status = RES_ERROR;
  return status;
}


int S_WRITE(FILE* handler, const void* reg, unsigned long cantidad) {
  int status = RES_ERROR;
  return status;
}

int S_DESTROY(const char* nombre_fisico) {
  int status = RES_ERROR;
  return status;
}

