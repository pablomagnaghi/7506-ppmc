#ifndef __secuencial_hpp__
#define __secuencial_hpp__

#include "../comun_cpp/constantes.hpp"

#include <cstdio>

int S_CREATE(const char* nombre_fisico);

int S_OPEN(const char* nombre_fisico, int modo, FILE ** fh);

int S_READ(FILE* handler, void* reg);

int S_CLOSE(FILE* handler);

int S_WRITE(FILE* handler, const void* reg, unsigned long cantidad);

int S_DESTROY(const char* nombre_fisico);

#endif /* __secuencial_hpp__ */
