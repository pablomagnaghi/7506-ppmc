#include "cataloger.hpp"

using namespace std;

Cataloger::Cataloger(){

}

Cataloger::~Cataloger(){

}

void Cataloger::operator()(const std::string& token) {
  cout << "catalogado " << token << endl;
}

