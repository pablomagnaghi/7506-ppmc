#ifndef __cataloger_hpp__
#define __cataloger_hpp__

#include <string>
#include <iostream>

class Cataloger {
public:
  Cataloger();
  ~Cataloger();
  void operator()(const std::string& token);
private:
  //file_backend;


};

#endif /* __cataloger_hpp__ */
