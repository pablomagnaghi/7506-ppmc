#include "../proxy/proxy.hpp"

#include <iostream>
#include <cstring>

#include <cstdlib>

using namespace std;

void show_options (char* name) {
  cout << "Usar: " << name << " [opciones] " << endl;
  cout << "-pl                  Listar los directorios agregados al motor "<< endl;
  cout << "-pa directorio       Agrega directorio para ser indexado" << endl;
  cout << "-pd directorio       Elimina directorio para ser indexado" << endl;
  cout << "-s  query            Busca en el catalogo general" << endl;
  cout << "-c catalogo -s query Busca en el catalogo especifico" << endl;
}


int main(int argc, char* argv[]) {
  bool error = false;
  string command;

  string pipe_in_path(getenv("HOME"));
  string pipe_out_path(pipe_in_path);

  pipe_in_path +="/.catalogo/pipe_in"; //@todo hardcoded
  pipe_out_path += "/.catalogo/pipe_out"; //@todo hardcoded

  Proxy server(pipe_out_path, pipe_in_path);
  if (argc == 2 && ! strcmp("-pl", argv[1])) {
    server.send("listar"); 
    cout << server.recv() << endl;
  } else if (argc == 3) {
    if (!strcmp("-pa", argv[1])){
      command = "alta ";
      command += argv[2];
      server.send(command.c_str());
    } else if (!strcmp("-pd", argv[1])) {
      command ="baja ";
      command += argv[2];
      server.send(command.c_str());
    } else if (!strcmp("-s", argv[1])) {
      command = "fullquery ";
      command += argv[2];
      server.send(command.c_str());
      cout << server.recv() << endl;
    } else {
      error = true;
    }    
  } else if (argc == 5 && !strcmp("-c", argv[1]) && !strcmp("-s",argv[3])){
    command =  "query ";
    command += argv[2];
    command += " ";
    command += argv[3];
    server.send(command.c_str());
    cout << server.recv() << endl;
  } else {
    error = true;
  }


  if (error) {
    show_options(argv[0]);
    return 1;
  }
  return 0;
}

