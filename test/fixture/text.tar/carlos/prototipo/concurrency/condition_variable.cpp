#include "condition_variable.hpp"
using namespace concurrency;

ConditionVariable::ConditionVariable( Mutex& m):mutex(m){
	pthread_cond_init(&cv,0);
}

int ConditionVariable::wait() {
	return pthread_cond_wait(&cv,&mutex.mutex);
}

int ConditionVariable::broadcast(){
	return pthread_cond_broadcast(&cv);
}

ConditionVariable::~ConditionVariable(){
	pthread_cond_destroy(&cv);
}

