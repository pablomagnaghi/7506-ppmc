#ifndef __CONDITION_VARIABLE_H__
#define __CONDITION_VARIABLE_H__

#include "mutex.hpp"

#include <pthread.h>

namespace concurrency {

class ConditionVariable {
public:
	ConditionVariable( Mutex& m);
	int wait();
	int broadcast();
	~ConditionVariable();
private:
	pthread_cond_t cv;
	Mutex& mutex;
	ConditionVariable(const ConditionVariable&);
	ConditionVariable& operator=(const ConditionVariable&);
};

}
#endif // __CONDITION_VARIABLE_H__
