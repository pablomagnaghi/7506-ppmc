/*
v19
*/

#include "mutex.hpp"
#include "thread.hpp"
#include "condition_variable.hpp"


#include <cassert>

#include <string>
#include <iostream>
#include <vector>

static const int MAXTASK=100;
static const int BUFFERSIZE=11;
static const int MAXPRODUCERCOUNT=20;
static const int MAXCONSUMERCOUNT=30;
static const int MAXTHREADCOUNT=MAXPRODUCERCOUNT+MAXCONSUMERCOUNT;

using namespace concurrency;

struct buffer_t {
	int count;
	int size;
	Mutex* mutex;
	ConditionVariable* not_empty;
	ConditionVariable* empty;
};

struct task_t {
	int count;
	int max;
};
class MyThread;
struct job_t {
	int id;
	struct buffer_t* buffer;
	struct task_t* task;
	MyThread * thread;
	int count;
	int misses;
};

int error(const std::string&  msg){
        std::cout << msg << std::endl;
        return 0;
}

class MyThread: public Thread {
public:
	MyThread(struct job_t* a):args(a){};
protected:
	struct job_t* args;
};

class Producer: public MyThread {
public:
	Producer(struct job_t* a): MyThread(a){};
	int run() {
		struct job_t* job = (struct job_t*) args;
		struct buffer_t* buffer=(struct buffer_t* ) job->buffer;
		struct task_t * task=(struct task_t* ) job->task;
        	int end=0;
		int status=0;
		status=buffer->mutex->lock();
	        assert(status == 0 || error("Error mutex lock"));
        	while (! end  ){
			buffer->empty->wait();
			if (task->count >= task->max) {
				end=1;
			} else {
				if (buffer->count == buffer->size) {
					++job->misses;
				} else {
					while (buffer->count < buffer->size && task->count < task->max) {
						++job->count;
						++task->count;
						++buffer->count;
					}
				}
			}
			buffer->not_empty->broadcast();
		}
		status=buffer->mutex->unlock();
	        assert(status == 0 || error("Error mutex unlock"));
		return 0;
	}
};

class Consumer: public MyThread {
public:
	Consumer(struct job_t* a): MyThread(a){};
	int run() {
        	struct job_t* job = (struct job_t* ) args;
	        struct buffer_t* buffer=(struct buffer_t* ) job->buffer;
		struct task_t* task=(struct task_t* ) job->task;
		int end=0;
		int status=0;
		status=buffer->mutex->lock();
        	assert(status == 0 || error("Error mutex lock"));
	        while (! end  ){
			buffer->not_empty->wait();
                	if (task->count >= task->max) {
                        	end=1;
	                } 
			if (buffer->count == 0) {
				++job->misses;
			} else {
		                while (buffer->count > 0 ) {
        		                ++job->count;
                		        --buffer->count;
				}
        	       	}
			buffer->empty->broadcast();
	        }
		status=buffer->mutex->unlock();
	        assert(status == 0 || error("Error mutex unlock"));
		return 0;
	}
};

int main(int argc, char * argv[]) {
	std::cout <<"V19"<< std::endl;

	int status=0;

	// buffer init
	struct buffer_t buffer;
	buffer.count=0;
	buffer.size=BUFFERSIZE;
	buffer.mutex=new Mutex();
	assert(buffer.mutex != 0 || error("Error mutex init"));
	
	buffer.not_empty=new ConditionVariable(*buffer.mutex);
	assert(buffer.not_empty != 0 || error("Error cond init"));

	buffer.empty=new ConditionVariable(*buffer.mutex);
	assert(buffer.empty != 0 || error("Error cond init"));

	// task init
	struct task_t task;
	task.count=0;
	task.max=MAXTASK;

	// job init
	std::vector< struct job_t*> job;

	for (int i=0; i < MAXTHREADCOUNT; ++i) {
		struct job_t* thisjob = new job_t;
                thisjob->id=i;
                thisjob->buffer=&buffer;
		thisjob->task=&task;
		thisjob->count=0;
		thisjob->misses=0;
		job.push_back(thisjob);
	}

	// thread creation
	int threadcount=0;
	for(int i=0; i<MAXPRODUCERCOUNT  ; ++i) {
		job[threadcount]->thread=new Producer(job[threadcount]);
		assert(job[threadcount]->thread != 0 || error("Error thread create"));
		status=job[threadcount]->thread->create();
		assert(status==0 || error("Error thread start"));
		++threadcount;
	}

        for(int i=0; i<MAXCONSUMERCOUNT  ; ++i) {
		job[threadcount]->thread=new Consumer(job[threadcount]);
		assert(job[threadcount]->thread != 0 || error("Error thread create"));
		status=job[threadcount]->thread->create();
		assert(status==0 || error("Error thread start"));
		++threadcount;
        }

	buffer.empty->broadcast();

	// thread joining
	for(int i=0; i<MAXTHREADCOUNT; ++i) {
		status=job[i]->thread->join();
		assert(status == 0 || error("Error thread join"));
	}

	// reporting
	std::cout << "Result ";
	int total_produced=0;
	int total_consumed=0;
	for(int i=0; i<MAXPRODUCERCOUNT; ++i) {
		std::cout << " " <<  job[i]->count;
		total_produced+=job[i]->count;
	}

	std::cout << " :: ";

	for(int i=MAXPRODUCERCOUNT; i< MAXTHREADCOUNT; ++i) {
                std::cout << " " << job[i]->count;
                total_consumed+=job[i]->count;
	}

	std::cout << std::endl << "Total produced: "<< total_produced << " consumed: " << total_consumed << std::endl;

	std::cout << "Misses: ";
        int total_misses=0;
        for(int i=0; i< MAXTHREADCOUNT; ++i) {
		std::cout << " " << job[i]->misses;
                total_misses+=job[i]->misses;
        }

	std::cout << std::endl << "Total misses: " <<  total_misses << std::endl ;

	// cleaning

        for(int i=0; i<MAXTHREADCOUNT; ++i) {
		delete(job[i]->thread);
		delete(job[i]);
        }
	delete(buffer.not_empty);
//        status=pthread_cond_destroy(&buffer.not_empty);
//	assert(status == 0 || error("Error cond destroy"));

	delete(buffer.empty);
//	status=pthread_cond_destroy(&buffer.empty);
//	assert(status == 0 || error("Error cond destroy"));

	delete(buffer.mutex);
 //       status = pthread_mutex_destroy(&buffer.mutex);
//	assert(status == 0 || error("Error mutex destroy"));

	return 0;
}
