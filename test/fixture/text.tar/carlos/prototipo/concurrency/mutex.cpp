#include "mutex.hpp"
#include <errno.h>

using namespace concurrency;

// todo: considerar usar lock_count en lugar de bool locked

Mutex::Mutex(){
    locked=false;
    status=0;
    pthread_mutex_init(&mutex,0);
}

int Mutex::lock(){
    status=pthread_mutex_lock(&mutex);
    locked= (status == 0);
    return status;
}

int Mutex::trylock(){
    status = pthread_mutex_trylock(&mutex);
    if (status ==0) {
      locked  = true;
      return 1;
    }
    if (status == EBUSY) {
      locked = false;
      return 0;
    }
    return 0;
}

int Mutex::unlock(){
    status = pthread_mutex_unlock(&mutex);
    locked = !(status == 0);
    return status;
}

Mutex::~Mutex(){
    if (locked) {
        unlock();
    }
    pthread_mutex_destroy(&mutex);
}


