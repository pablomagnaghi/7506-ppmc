#ifndef __MUTEX_H__
#define __MUTEX_H__
#include <pthread.h>

namespace concurrency {

class ConditionVariable;

class Mutex {
	friend class ConditionVariable;
public:
	Mutex();
	int lock();
	int trylock();
        int unlock();
	~Mutex();
private:
	pthread_mutex_t mutex;
	Mutex(const Mutex&);
	Mutex& operator=(const Mutex&);
    int status;
    bool locked;
};

}

#endif // __MUTEX_H__
