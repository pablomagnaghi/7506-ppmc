#include "thread.hpp"
#include <signal.h>

using namespace concurrency;

Thread::Thread(){
    started=false;
}

void * Thread::start(void * o) {
    Thread * thread = static_cast< Thread* >(o);
    thread->started=true;
    thread->run();
    return 0;
}

int Thread::create() {
    status=pthread_create(&thread,0,&start, this);
    return status;
}

int Thread::join() {
    if (started) {
        status=pthread_join(thread,0);
        started=false;
    } else {
        status=0; // todo: poner el valor correcto aca
    }
    return status;
}

Thread::~Thread(){
/*
ERRORS
 The pthread_kill() function shall fail if:

 ESRCH  No thread could be found corresponding to that specified by the given thread ID.

 EINVAL The value of the sig argument is an invalid or unsupported signal number.

Podriamos quizas precindir de started, simplemente enviar la signal

*/
    if (started) {
        pthread_kill(thread, 9);
    }

}

