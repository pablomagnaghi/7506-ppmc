#ifndef __THREAD_H__
#define __THREAD_H__

#include <pthread.h>

namespace concurrency {

class Thread {
public:
	Thread();

	int create() ;

	int join();

	virtual ~Thread();

protected:
        virtual int run()=0;
private:
        static void* start(void* o);

private:
        Thread(const Thread&);

        Thread& operator=(const Thread&);

        pthread_t thread;
    int status;
    bool started;
};

}
#endif // __THREAD_H__
