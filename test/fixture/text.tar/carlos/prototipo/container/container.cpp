#include "container.hpp"

using namespace std;

void Container::insert(int key, const std::string& value){
  elements.insert( make_pair( key, value ) );
}
std::string Container::find(int key){
  map<int, string>::iterator iter = elements.find(key);
  if( iter != elements.end() ) {
    return iter->second;
  }
  return "";

}

