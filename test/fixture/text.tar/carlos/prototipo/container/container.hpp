class Container;

#ifndef __container_hpp__
#define __container_hpp__
#include <map>
#include <string>

class Container {
public:
  void insert(int key, const std::string& value);
  std::string find(int key);


private:
 /* @todo: reemplazar map */
 std::map< int, std::string> elements;

};

#endif /* __container_hpp__ */
