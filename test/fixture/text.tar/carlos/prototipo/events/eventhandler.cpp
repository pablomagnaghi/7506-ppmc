#include "eventhandler.hpp"
#include <iostream>

using namespace std;
using namespace events;
#include "boost/filesystem.hpp"
using namespace boost::filesystem;

  void EventHandler::addDocument(const std::string& path, const std::string& file){
    cout << "------------------------------------" << endl;
    string target(path);
    if (file.compare("")) {
      target += "/";
      target += file;
    }

    cout << "analizando " <<  target << endl;
    istream* input = dataextractor.new_data_extractor(target.c_str());

    if( !input ) {
      cout << "Error opening input stream for extracting metadata from " << target << endl;
      return ;
    }
    string token;
    tokenizer.open(input);
    while (tokenizer >> token) {
      frequencer.add(token);
    }
    delete(input);

    frequencer.debug_show();
    // si hubo resultados
    //   agregar (path, file) a archivos conocidos, que devuelve un codigo
    //   agregar los resultados mas el codigo a catalogador
    //   cat.add(freq.get());


    tokenizer.close();
    frequencer.clear();
  }

  void EventHandler::recurse(const std::string& path, const std::string& file) {
    string target(path);
    if (file.compare("")) {
      target += "/";
      target += file;
    }

    cout << "-----------------------------------------" << endl;
    cout << "recursing " << target << endl;
    if (is_regular_file(target)){
      addDocument( path,file );
      
    } else if (is_directory(target)) {
      for (directory_iterator itr(path); itr!=directory_iterator(); ++itr) {
        //cerr << "inode " << itr->path().inode() << endl;
        recurse( target , itr->path().filename());
      }
    } else {
       cout << "Recurse: not file neither directory " << target << endl;
    }
  }

  bool EventHandler::handle(const std::string& line) {
    int pos = line.find_first_of(" ");
    response.clear();
    string command(line.substr(0,pos));
    string args(line.substr(pos+1));
    //cout << "EventHandler command: " << command << " args: " << args << endl;
    if (!command.compare("alta")) {
      // controlar que sea uno solo
      recurse(args,"");
    } else if (!command.compare("baja")) {
      response =  "Comando baja no implementado";
    } else if (!command.compare("listar")) {
      response = "Comando listar no implementado";
    } else if (!command.compare("shutdown")) {
      response = "Apagando servicio";
      return false;
    } else if (!command.compare("event")) {
      response =  "Debugging ";
      response +=  command ;
      response += " con " ;
      response += args;
    } else {
      response = "Comando desconocido ";
      response += command;
    }
    return true;
  }
