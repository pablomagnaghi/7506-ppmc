#ifndef __eventhandler_hpp__
#define __eventhandler_hpp__

#include "eventmonitor.hpp"

#include "../parser/wordvalidator.hpp"
#include "../parser/tokenizer.hpp"
#include "../cataloger/cataloger.hpp"
#include "../frequencer/frequencer.hpp"
#include "../libextractor/dataextractorbuilder.hpp"

#include <string>
namespace events {

class EventHandler {
public:
  EventHandler(EventMonitor& em):event_monitor(em){};
  void addDocument(const std::string& path, const std::string& file);

  void recurse(const std::string& path, const std::string& file);

  bool handle(const std::string& line);

private:
  Cataloger cat;
  Tokenizer tokenizer;
  Frequencer frequencer;
  DataExtractorBuilder dataextractor;
  EventMonitor& event_monitor;
public:
  std::string response;
};
}
#endif /* __eventhandler_hpp__ */
