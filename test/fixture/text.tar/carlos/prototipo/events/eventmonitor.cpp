#include "eventmonitor.hpp"

using namespace inotify;
using namespace events;

EventMonitor::EventMonitor(){
  watch = new InotifyWatch(watches);
}

std::string EventMonitor::getEvent(){
  return watch->read();
}

bool EventMonitor::addWatchedDir(const std::string& dir){
  watch->add(dir);
  return 1;
}

bool EventMonitor::setWatchedFile(const std::string& file){
  watch->add(file);
  return 1;
}

EventMonitor::~EventMonitor(){
  delete watch;
}

