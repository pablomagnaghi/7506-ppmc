#ifndef __eventmonitor_hpp__
#define __eventmonitor_hpp__

#include "../container/container.hpp"
#include "../inotify/inotifywatch.hpp"

#include <string>
namespace events {
class EventMonitor{
public:
   EventMonitor();

   std::string getEvent();

   bool addWatchedDir(const std::string& dir);

   bool setWatchedFile(const std::string& file);

   ~EventMonitor();

private:
  char event[100];
  Container watches;
  inotify::InotifyWatch* watch;
};
}
#endif /* __eventmonitor_hpp__ */
