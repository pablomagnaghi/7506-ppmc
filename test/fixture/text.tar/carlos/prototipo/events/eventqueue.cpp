#include "eventqueue.hpp"
#include <iostream>

using namespace std;
using namespace concurrency;
using namespace events;

std::string EventQueue::getEvent() {
  if (events.size()==0) {
    cout << "    miss" << endl;
    return "";
  }
  string event= events.front();
  events.pop();
  return event;
}  

void EventQueue::push( std::string event) {
  cout << "    push " << event << endl;
  events.push(event);
}

int EventQueue::size(){
  return events.size();
}

EventQueue::EventQueue(){
  closed = false;
}

EventQueue::~EventQueue(){
}

