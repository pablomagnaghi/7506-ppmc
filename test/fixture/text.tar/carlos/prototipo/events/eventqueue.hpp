#ifndef __eventqueue_hpp__
#define __eventqueue_hpp__

#include "../concurrency/mutex.hpp"

#include <queue>
#include <string>
/*
 * @todo hacer miembros privados
 */
namespace events {
struct EventQueue {
  concurrency::Mutex mutex;
  std::queue<std::string> events;
  bool closed;
public:
  std::string getEvent();

  int size();


  void push( std::string event);

  EventQueue();

  ~EventQueue();

};
}
#endif /* __eventqueue_hpp__ */
