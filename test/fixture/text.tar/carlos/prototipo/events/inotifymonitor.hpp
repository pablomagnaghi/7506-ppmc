#ifndef __inotifymonitor_hpp__
#define __inotifymonitor_hpp__

#include "monitor.hpp"
namespace events {
class InotifyMonitor: public Monitor;


}
#endif /* __inotifymonitor_hpp__ */
