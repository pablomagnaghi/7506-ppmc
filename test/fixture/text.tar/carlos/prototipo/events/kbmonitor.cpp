#include "kbmonitor.hpp"

#include "../concurrency/mutex.hpp"
#include "../concurrency/thread.hpp"
#include "../concurrency/condition_variable.hpp"

#include <iostream>
#include <string>
#include <cstring>

using namespace concurrency;
using namespace std;
using namespace events;

// thread que pone en el queue lo que lee de teclado
KBMonitor::KBMonitor(EventQueue& q):Monitor(q){}

int KBMonitor::run() {
  cout << "  kbmonitor running" << endl;
  int end=0;
  int status=0;
  while (! end  ){
    cout << "  kbmonitor getline" << endl;
    memset(event,0,100); //@todo hardcoded
    cin.getline(event,99); //@todo hardcoded
    cout << "  kbmonitor waiting" << endl;
    events.mutex.lock();
    cout << "  kbmonitor pushing" << endl;
    events.push(string(event));
    end = events.closed;
    events.mutex.unlock();
  }
  cout << "  kbmonitor exiting" << endl;
  if (status != 0 ) throw 1; //@todo exception
  return 0;
}

