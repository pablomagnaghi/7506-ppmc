#ifndef __kbmonitor_hpp__
#define __kbmonitor_hpp__

#include "monitor.hpp"
namespace events {
class KBMonitor:public Monitor {
public:
  KBMonitor(EventQueue& q);
  int run();
private:
  char event[100]; //@todo hardcoded
};
}
#endif /* __kbmonitor_hpp__ */

