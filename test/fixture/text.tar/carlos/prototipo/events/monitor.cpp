#include "monitor.hpp"

using namespace events;

Monitor::Monitor(EventQueue& q):events(q){}

Monitor::~Monitor(){}
