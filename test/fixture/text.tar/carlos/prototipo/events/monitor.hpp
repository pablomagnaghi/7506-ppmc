#ifndef __monitor_hpp__
#define __monitor_hpp__

#include "eventqueue.hpp"
#include "../concurrency/thread.hpp"
namespace events {
class Monitor:public concurrency::Thread {
public:
  Monitor(EventQueue& q);
  virtual ~Monitor();
protected:
  EventQueue& events;
}; 
}
#endif /* __monitor_hpp__ */
