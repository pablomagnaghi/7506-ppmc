#include "pipemonitor.hpp"
#include "sys/stat.h"

#include <cerrno>
#include <cstring>
#include <iostream>
#include <fstream>
#include <unistd.h>

using namespace std;
using namespace events;

PipeMonitor::PipeMonitor(EventQueue& q, Proxy& server):Monitor(q), proxy(server){
}

int PipeMonitor::run(){
  cout << "  pipemonitor running" << endl;

  int end=0;
  while (! end  ){
    cout << "  pipemonitor getline" << endl;
    string event2 = proxy.recv();
    if (event2.size()){
      cout << "  pipemonitor waiting" << endl;
      events.mutex.lock();
      cout << "  pipemonitor pushing" << endl;
      events.push(event2);
      end = events.closed;
      events.mutex.unlock();
    }
    sleep(1); 
  }
  cout << "  pipemonitor exiting" << endl;

  return 0;
}
