#ifndef __pipemonitor_hpp__
#define __pipemonitor_hpp__

#include "monitor.hpp"

#include "../proxy/proxy.hpp"

#include <string>
namespace events {
class PipeMonitor: public Monitor {
public:
  PipeMonitor(EventQueue&q, Proxy& server);
  int run();
private:
  Proxy& proxy;
  char event[100]; //@todo hardcoded


};
}
#endif /* __pipemonitor_hpp__ */
