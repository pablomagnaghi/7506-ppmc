#ifndef __directory_hpp__
#define __directory_hpp__

#include <string>

namespace filesystem {

struct Directory {
  std::string name;
  Directory* parent;
  int wd;
};

}
#endif /* __directory_hpp__ */
