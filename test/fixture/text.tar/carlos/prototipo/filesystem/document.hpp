#ifndef __document_hpp__
#define __document_hpp__

#include "directory.hpp"

namespace filesystem {

struct Document {
  std::string name;
  Directory* parent;
};

}

#endif /* __document_hpp__ */ 
