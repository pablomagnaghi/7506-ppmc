#include "frequencer.hpp"

using namespace std;

Frequencer::Frequencer(){

}

Frequencer::~Frequencer(){

}

void Frequencer::clear() {
  freq.clear();
}

void Frequencer::add(const std::string& token){
  freq[token]=freq[token] + 1;
}

std::map<std::string, int>& Frequencer::getFreq() {
  return freq;
}

void Frequencer::debug_show(const char* doc) {

  map<string,int>::iterator it;

  for (it=freq.begin(); it!=freq.end(); ++it) {
    cerr << (*it).first << " : " << doc <<" : " << (*it).second << endl;
  }

}
