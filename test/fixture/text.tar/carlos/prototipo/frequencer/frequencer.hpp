#ifndef __frequencer_hpp__
#define __frequencer_hpp__

#include <string>
#include <iostream>
#include <map>
class Frequencer {
public:
  Frequencer();
  ~Frequencer();
  void clear();
  void add(const std::string& token);
  std::map< std::string, int >& getFreq();
  void debug_show(const char* doc);
private:
  std::map< std::string, int > freq;

};

#endif /* __frequencer_hpp__ */
