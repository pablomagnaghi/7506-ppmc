#include <iostream>
#include <iostream>

#include <string>
#include "frequencer.hpp"

using namespace std;

int main(int argc, char* argv[]) {
  Frequencer frq;

  string token;

  while (cin >> token) {
    frq.add(token);     
  }

  frq.debug_show(argv[1]);
  return 0;
}
