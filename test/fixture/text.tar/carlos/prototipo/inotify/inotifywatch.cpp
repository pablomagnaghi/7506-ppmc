#include <cerrno>
#include <iostream>
#include "inotifywatch.hpp"


using namespace std;
using namespace inotify;


/*
 * 
 *
 */
InotifyWatch::InotifyWatch(Container & watches2) throw (InotifyException) :watches(watches2) {
  int last_error;
  ifd = inotify_init();
  last_error = errno;
  if (ifd == -1) {
    switch (last_error) {
      case EINVAL: throw InotifyException("An invalid value was specified in flags.");
        break;
      case EMFILE: throw InotifyException("The user limit on the total number of inotify instances has been reached.");
        break;
      case ENFILE: throw InotifyException("The system limit on the total number of file descriptors has been reached.");
        break;
      case ENOMEM: throw InotifyException("Insufficient kernel memory is available.");
        break;
    }
  }
}


/*
 *  wrapper para IN_ALL_EVENTS
 *
 */
void InotifyWatch::add(const std::string& path) throw (InotifyException) {
  add(path,IN_ALL_EVENTS);
}

void InotifyWatch::reset()  throw (InotifyException){

}

void InotifyWatch::rm(const std::string& path) throw (InotifyException){
/*
  string path = watches.find();
  if(  path.size()== 0) {
    cerr << "evento sobre path: " << path << " " ;
    return;
  }
*/
/*
       int inotify_rm_watch(int fd, uint32_t wd);

DESCRIPTION
       inotify_rm_watch() removes the watch associated with the watch descriptor wd from the inotify instance associated with the file descriptor fd.

       Removing a watch causes an IN_IGNORED event to be generated for this watch descriptor.  (See inotify(7).)

RETURN VALUE
       On success, inotify_rm_watch() returns zero, or -1 if an error occurred (in which case, errno is set appropriately).

ERRORS
       EBADF  fd is not a valid file descriptor.

       EINVAL The watch descriptor wd is not valid; or fd is not an inotify file descriptor.
*/
}



void InotifyWatch::add(const std::string& path, int events)  throw (InotifyException){
  int last_error;
  int watch;
  watch = inotify_add_watch(ifd, path.c_str(), events);

  last_error= errno;
  if (watch != -1) {
    watches.insert( watch, path );
  } else {
    switch (last_error)  {
      case EACCES: throw InotifyException("Read access to the given file is not permitted.");
        break;
      case EBADF:  throw InotifyException("The given file descriptor is not valid.");
        break;
      case EFAULT: throw InotifyException("pathname points outside of the process's accessible address space.");
        break;
      case EINVAL: throw InotifyException("The given event mask contains no valid events; or fd is not an inotify file descriptor.");
        break;
      case ENOMEM: throw InotifyException("Insufficient kernel memory was available.");
        break;
      case ENOSPC: throw InotifyException("The user limit on the total number of inotify watches was reached or the kernel failed to allocate a needed resource");
        break;
    }
  }
}

/* 
 *
 *
 *
 */

#define BUFFER_LEN  (sizeof (struct inotify_event) + 16 ) * 1024

std::string InotifyWatch::read() throw (InotifyException) {
  string result;
  if (!event_queue.empty()) {
    result = event_queue.front();
    event_queue.pop();
    return result;
  }

  cerr << "READ CALL" << endl;
  char event_buffer[BUFFER_LEN];
  struct inotify_event* event = (struct inotify_event*) event_buffer;

  int size = ::read(ifd, event, sizeof(event_buffer));
  int event_size = sizeof (struct inotify_event) + event->len;
  if (size == EINVAL ) {
    cerr << "Read EINVAL" << endl;
  } else {
    while ( event_size <= size ) {
      cerr << "EVENT..." << endl;
      size -= event_size;
      string path = watches.find(event->wd);
      if(  path.size()!= 0) {
        result = "event on path " + path + " " ;
        cerr << "evento sobre path: " << path << " " ;
      }  

      if (event->len > 0) {
        string tmp(event->name);
        result += "event on name: " + tmp + " " ;
        cerr << " evento sobre name: " << event->name << " wd: " << event->wd << "  ";
      }
 
      if (event->mask & IN_ATTRIB)        {cerr << "IN_ATTRIB"; result += "IN_ATTRIB";}
      if (event->mask & IN_CLOSE_WRITE)   {cerr << "IN_CLOSE_WRITE"; result += "IN_CLOSE_WRITE";}
      if (event->mask & IN_CLOSE_NOWRITE) {cerr << "IN_CLOSE_NOWRITE"; result += "IN_CLOSE_NOWRITE";}
      if (event->mask & IN_CREATE)        {cerr << "IN_CREATE"; result += "IN_CREATE";}
      if (event->mask & IN_DELETE)        {cerr << "IN_DELETE"; result += "IN_DELETE";}
      if (event->mask & IN_DELETE_SELF)   {cerr << "IN_DELETE_SELF"; result += "IN_DELETE_SELF";}
      if (event->mask & IN_MODIFY)        {cerr << "IN_MODIFY"; result += "IN_MODIFY";}
      if (event->mask & IN_MOVE_SELF)     {cerr << "IN_MOVE_SELF"; result += "IN_MOVE_SELF";}
      if (event->mask & IN_MOVED_FROM)    {cerr << "IN_MOVED_FROM"; result += "IN_MOVED_FROM"; }
      if (event->mask & IN_MOVED_TO)      {cerr << "IN_MOVED_TO"; result += "IN_MOVED_TO";}
       if (event->mask & IN_OPEN)         {cerr << "IN_OPEN"; result += "IN_OPEN";}

      if (event->mask & IN_IGNORED) { cerr << " XX IN_IGNORED "; result += " XX IN_IGNORED ";}
      if (event->mask & IN_ISDIR) { cerr << " XX IN_ISDIR "; result += " XX IN_ISDIR ";}
      if (event->mask & IN_Q_OVERFLOW) {
        cerr << " XX IN_Q_OVERFLOW ";
        result += "XX IN_Q_OVERFLOW ";
        throw InotifyException("IN_Q_OVERFLOW");
      }
      if (event->mask & IN_UNMOUNT)  {cerr << " XX_IN_UNMOUNT "; result +=" XX_IN_UNMOUNT ";}
      cerr << endl;
      event_queue.push(result);
    }
  }
  result = event_queue.front();
  event_queue.pop();
  return result;
}


InotifyWatch::~InotifyWatch(){
  close(ifd);
}

