#ifndef __inotifywatch_hpp__
#define __inotifywatch_hpp__

#include "../container/container.hpp"
#include <string>
#include <exception>
#include <queue>

namespace inotify {

#include <sys/inotify.h>

class InotifyException:public std::exception {
public:
  InotifyException(const std::string msg2);
  virtual const char* what() const throw();
private:
  const std::string& msg;
};



class InotifyWatch {
public:
  InotifyWatch(Container& watches2) throw (InotifyException) ;
  void add(const std::string& path)  throw (InotifyException);
  void add(const std::string& path, int mode) throw (InotifyException);
  void rm(const std::string& path) throw (InotifyException);
  void reset() throw (InotifyException);
  std::string read() throw (InotifyException);
  ~InotifyWatch();
private:
  int ifd;
  int events;
  Container& watches;
  /* @todo: validar uso queue o reemplazar */
  std::queue<std::string> event_queue;
};

}
#endif /* __inotifywatch_hpp__ */

