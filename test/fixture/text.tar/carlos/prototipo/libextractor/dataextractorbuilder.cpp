#include "dataextractorbuilder.hpp"

#include <sstream>

using namespace std;

DataExtractorBuilder::DataExtractorBuilder(){
  // cargar estos datos de disco...
  datalist.push_back(".txt");
  datalist.push_back(".c");
  datalist.push_back(".py");
  datalist.push_back(".php");
  datalist.push_back(".cpp");

  metadatalist.push_back(".pdf");
  metadatalist.push_back(".jpg");
  metadatalist.push_back(".png");
  metadatalist.push_back(".mp3");

}

DataExtractorBuilder::~DataExtractorBuilder(){
}

int DataExtractorBuilder::is_data(const char * name) {
  string path(name);
  for (unsigned int i=0; i<datalist.size(); ++i) {
    if (path.substr(path.size()-datalist[i].size()).compare(datalist[i]) == 0) {
      return 1;
    }  
  }
  return 0;
}

int DataExtractorBuilder::is_metadata(const char * name) {
  string path(name);
  for (unsigned int i=0; i<metadatalist.size(); ++i) {
    if (path.substr(path.size()-metadatalist[i].size()).compare(metadatalist[i]) == 0) {
      return 1;
    }
  }
  return 0;
}

istream* DataExtractorBuilder::new_from_string(const char* buffer) {
  stringstream*  inputString = new stringstream();
  *inputString << buffer;
  return inputString;
}

istream* DataExtractorBuilder::new_from_file(const char* path) {
   ifstream* inputFile = new ifstream();
   inputFile->open(path);
   return inputFile;
}

/*
 * Queria devolver un puntero al libextractor para que sea
 * leido token a token, pero no funciona:
 *    Libextractor * e = new Libextractor();
 *    e->open(path);
 *    return e;
 *
 * Igual vino bien para poder utilizar una sola instancia

 */ 
istream* DataExtractorBuilder::new_data_extractor(const char* path) {
  if (is_data(path)) {
     cerr << "new from file text" << endl;
     return new_from_file(path);
  }
  if (!is_metadata(path)) {
     cerr << "no valid file" << endl;
     return 0;
  }
  cerr << "new from file metadata" << endl;
  stringstream*  inputString = new stringstream();
  
  extractor.open(path);
  string token;
  while (extractor >> token){
    *inputString << token; 
  }
  extractor.close();
  return inputString;
}

