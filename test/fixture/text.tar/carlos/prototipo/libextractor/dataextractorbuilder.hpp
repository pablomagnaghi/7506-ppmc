#ifndef __dataextractorbuilder_hpp__
#define __dataextractorbuilder_hpp__

#include "../libextractor/libextractor.hpp"

#include <iostream>
#include <fstream>

#include <vector>
#include <string>

class DataExtractorBuilder {
public:
  DataExtractorBuilder();
  ~DataExtractorBuilder();
  std::istream* new_data_extractor(const char* path);
  std::istream* new_from_file(const char* path);
  std::istream* new_from_string(const char* buffer);
  int is_data(const char * name);
  int is_metadata(const char * name);

private:
  std::vector<std::string> datalist;
  std::vector<std::string> metadatalist;
  Libextractor extractor;

};

#endif /* __dataextractorbuilder_hpp__ */
