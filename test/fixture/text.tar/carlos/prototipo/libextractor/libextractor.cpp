#include "libextractor.hpp"

#include <string>
#include <iostream>

using namespace std;

Libextractor::Libextractor() {
  tags = 0;
  cursor = 0;
  plugins = 0;
  plugins = EXTRACTOR_addLibrary(plugins, "libextractor_png");
  plugins = EXTRACTOR_addLibrary(plugins, "libextractor_mp3");
  plugins = EXTRACTOR_addLibrary(plugins, "libextractor_id3v2");
  plugins = EXTRACTOR_addLibrary(plugins, "libextractor_id3v23");
  plugins = EXTRACTOR_addLibrary(plugins, "libextractor_id3v24");
  plugins = EXTRACTOR_addLibrary(plugins, "libextractor_jpeg");
  plugins = EXTRACTOR_addLibraryLast(plugins, "libextractor_pdf");
  if (! plugins) {
    cerr << "Revise que se pueda acceder a los plugins en LD_LIBRARY_PATH" << endl;
    cerr << "export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/lib64/libextractor" << endl;
    cerr << "Esta es la lista de plugins disponibles" << endl <<  EXTRACTOR_DEFAULT_LIBRARIES << endl;
    throw 1; //@todo exception
  }
}

void Libextractor::open(const char* filename) {
  tags = EXTRACTOR_getKeywords(plugins, filename);
  cursor = tags;
}

void Libextractor::close(){
  if (tags) {
    EXTRACTOR_freeKeywords(tags);
    tags = 0;
  }
}

Libextractor::~Libextractor() {
  close();
  EXTRACTOR_removeAll(plugins); 
}

std::istream& operator>>( Libextractor& t, std::string& out )  {
  if (t.cursor == 0) {
     t.setstate(ios_base::eofbit);
     return t;
  }
  out = t.cursor->keyword ;
  out += " ";
  t.cursor = t.cursor->next;
  t.clear();
  return cin;    //@todo parche horrible
}

std::istream* operator>>( Libextractor* t, std::string& out )  {
  if (t->cursor == 0) {
     t->setstate(ios_base::eofbit);
     return 0;
  }
  out = t->cursor->keyword ;
  out += " ";
  t->cursor = t->cursor->next;
  t->clear();
  return t;    // parche horrible
}



// y usar operator >> para extraer los tokens

void Libextractor::extract(const char* filename, std::stringstream& ss) {
  tags = EXTRACTOR_getKeywords(plugins, filename);
  cursor = tags;

/*  
    int count = EXTRACTOR_countKeywords(tags);
    cerr << "Impresion de la libreria para " <<  filename << endl;
    EXTRACTOR_printKeywords(stdout, tags);
    EXTRACTOR_KeywordList   * cursor = tags;
    cerr << "Impresion de la aplicacion para " <<  filename << endl;
    while (cursor) {
      cerr << "keyword: " << cursor->keyword << " type " <<  cursor->keywordType << endl;
      cursor = cursor->next;
    }
    cursor = tags;
*/
  while (cursor) {
     ss << cursor->keyword << " ";
     cursor = cursor->next;
  }

  EXTRACTOR_freeKeywords(tags);
  tags=0;
}

