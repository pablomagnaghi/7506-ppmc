#ifndef __libextractor_hpp__
#define __libextractor_hpp__

#include <extractor.h>
#include <iostream>
#include <sstream>
#include <string>

class Libextractor:public std::istream {
public:
  Libextractor();
  void open(const char* filename);
  void close();
  ~Libextractor();
  void extract(const char* filename, std::stringstream& ss);
  friend std::istream& operator>>( Libextractor& t, std::string& out );
  friend std::istream* operator>>( Libextractor* t, std::string& out );
private:
  EXTRACTOR_ExtractorList * plugins;
  EXTRACTOR_KeywordList   * tags;
  EXTRACTOR_KeywordList   * cursor;
};

std::istream& operator>>( Libextractor& t, std::string& out );
std::istream* operator>>( Libextractor* t, std::string& out );
#endif /*  __libextractor_hpp__ */
