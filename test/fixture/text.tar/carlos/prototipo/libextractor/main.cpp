#include "libextractor.hpp"
#include <string>
//#include <sstream>
#include <iostream>
/* 

Para ejecutar:
export LD_PATH=/usr/lib/libextractor
*/

using namespace std;

int main(int argc, char* argv[]) {
  if (argc != 2) {
     printf("Este programa recibe un y solo un argumento\n");
     return 1;
  }

  Libextractor * ptr = new Libextractor();

  string token;
  ptr->open(argv[1]);
  cout << argv[1] << " : " ;
  while ( ptr >> token) {
    cout << token << " .  ";
  }
  ptr->close();
  cout << endl;
  delete(ptr);

  Libextractor var;

  var.open(argv[1]);
  cout << argv[1] << " : " ;
  while ( var >> token) {
    cout << token << " .  ";
  }
  var.close();
  cout << endl;

  return 0;
}

