#include "log.hpp"
using namespace std;

void Log::setOutput(std::ostream* o) {
  output = o;
}

void Log::log( std::string msg, std::string source, int level) const {
  *output << source << "::" << msg << endl;
}

Log::Log(){}

