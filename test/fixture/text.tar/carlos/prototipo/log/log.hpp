#ifndef __log_hpp__
#define __log_hpp__

#include <iostream>
#include <string>
#include <ostream>

class Log{
public:
  static Log& getInstance() {
    static Log instance;
    return instance;
  }

  void log( std::string msg, std::string source, int level) const;
  void setOutput(std::ostream* o);

private:
  Log();
  Log(Log const&);
  Log& operator=(Log const&);
  std::ostream* output;
};

#endif /* __log_hpp__ */

