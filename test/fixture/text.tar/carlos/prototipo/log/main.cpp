#include "log.hpp"

using namespace std;
int main(int argc, char* argv[]) {

  Log &log = Log::getInstance();
  log.setOutput(&std::cout);
  log.log(string("hola"), string("que tal"), 0);

}
