#include <iostream>
#include <fstream>
#include <sstream>

#include <vector>
#include <string>
#include "wordvalidator.hpp"
#include "tokenizer.hpp"

using namespace std;

void catalogar(const std::string& token){
  cout << token << endl;
}

istream* new_from_string(const char* buffer) {
  stringstream*  inputString = new stringstream();
  *inputString << buffer;
  return inputString;
}

istream* new_from_file(const char* path) {
   ifstream* inputFile = new ifstream();
   inputFile->open(path);
   return inputFile;
}

int main(int argc, char* argv[]) {
   istream* input;

   if (argc==2) {
     input = new_from_string(argv[1]);
   } else if (argc==3){
     input = new_from_file(argv[2]);
   } else {
     cerr << "Modo de uso:" << endl;
     cerr << argv[0] << " \"texto c a catalogar con stop-words\"" << endl;
     cerr << argv[0] << " f archivo a catalogar" << endl << endl;
     cerr << "use   > /dev/null para ver la traza" << endl;
     cerr << "use   2> /dev/null para ver la salida" << endl;
     return 1;
   }

    if( !input ) {
     cerr << "Error opening input stream" << endl;
     return 2;
   }

   Tokenizer tokenizer(input);

   string token;

   while (tokenizer >> token) {
     cout << "token " << token << endl;
   }

  delete(input);
  return 0;
}
