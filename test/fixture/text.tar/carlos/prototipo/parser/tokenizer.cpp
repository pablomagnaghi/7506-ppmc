#include "tokenizer.hpp"

using namespace std;

Tokenizer::Tokenizer(){

}
void Tokenizer::open(std::istream* in) {
  input=in;
}

void Tokenizer::close(){

}

std::istream& operator>>( Tokenizer& t, std::string& out )  {
  string token;
  string subtoken;
  while (t.subInputString >> subtoken) {
    if ( t.validator.is_valid(subtoken)) {
      cerr << " .  " << subtoken;
      out=subtoken;
      return  *(t.input);
    }
  }

  while (*(t.input) >> token) {
    cerr << "debug: " << token << " --> " ;
    if (! t.validator.replace(token)) {
      if ( t.validator.is_valid(token)) {
        cerr << " valid:" << token;
        out = token;
        return *(t.input);
      }
    } else {
      cerr  << token << " --> ";
      t.subInputString.clear();
      t.subInputString << token;
      while (t.subInputString >> subtoken) {
        if ( t.validator.is_valid(subtoken)) {
          cerr << " .  " << subtoken;
          out= subtoken;
          return *(t.input);
        }
      }
    }
    cerr << endl;
  }
  return *(t.input);
}

