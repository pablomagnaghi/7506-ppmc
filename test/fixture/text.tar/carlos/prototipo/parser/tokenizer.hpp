#ifndef __tokenizer_hpp__
#define __tokenizer_hpp__

#include "wordvalidator.hpp"

#include <iostream>
#include <sstream>
#include <string>

class Tokenizer:public std::istream{
public:
  Tokenizer();
  void open(std::istream* in);
  void close();
  friend std::istream& operator>>( Tokenizer& t, std::string& out );
private:
  std::istream* input;
  std::stringstream subInputString;
  WordValidator validator;
};

std::istream& operator>>( Tokenizer& t, std::string& out );

#endif /* __tokenizer_hpp__ */
