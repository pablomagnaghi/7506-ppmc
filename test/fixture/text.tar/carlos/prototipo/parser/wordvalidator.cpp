#include "wordvalidator.hpp"

using namespace std;

WordValidator::WordValidator() {
  whitelist.push_back("c");
  whitelist.push_back("y");
  stopwords.push_back("a");
  stopwords.push_back("to");
  stopwords.push_back("the");
  badchars = "'!#$%&/()=?¡¿+-*[]{}-.,:;<>\\\"";
}

bool WordValidator::is_valid(const std::string& token) {
  if (in_whitelist(token)){
    return true;
  }
  if (token.size() == 1) {
    return false;
  }
  if (is_stop_word(token)) {
    return false;
  }
  return true;
}

bool WordValidator::replace(std::string& token){
  bool replaced=false;
  for (unsigned int i=0; i< token.size(); ++i) {
    if( ( badchars.find(token[i]) +1 != 0 )){
      replaced=true;
      token.replace( i, 1, 1, ' ');
    }
  }
  return replaced;
}

bool WordValidator::is_stop_word(const std::string& token) {
  vector<string> stopwords;
  vector <string>::iterator it;
  for( it = stopwords.begin(); it<stopwords.end(); ++it) {
    if ((*it).compare(token) == 0) return true;
  }
  return false;
}

bool WordValidator::in_whitelist(const std::string& token) {
  vector <string>::iterator it;
  for( it = whitelist.begin(); it<whitelist.end(); ++it) {
    if ((*it).compare(token) == 0) return true;
  }
  return false;
}

