class WordValidator;

#ifndef __wordvalidator_hpp__
#define __wordvalidator_hpp__

#include <vector>
#include <string>

class WordValidator {
public:
  WordValidator();
  bool is_valid(const std::string& token);
  bool replace(std::string& token);
private:
  bool is_stop_word(const std::string& token);
  bool in_whitelist(const std::string& token);

  std::vector<std::string> whitelist;
  std::string badchars;
  std::vector<std::string> stopwords;
};

#endif /* __wordvalidator_hpp__ */
