#include "proxy.hpp"

#include <iostream>
#include <fstream>
#include <cstring>
#include <sstream>

using namespace std;

Proxy::Proxy(const std::string& pipe_in, const std::string& pipe_out){
  in = pipe_in;
  out = pipe_out;

/*  int status = mkfifo(name.c_str(), S_IRUSR | S_IWUSR);
  int error = errno;
  cout << status << endl;
  if (status == -1 && error != EEXIST) {
    throw 1; //@todo exception
  }
*/


}

void Proxy::send(const char* msg){
  ofstream pipe;
  cerr << "Opening " << out << " for output" << endl;
  pipe.open(out.c_str());
  if (!pipe) {
    cerr << "std::string Proxy::send" << endl;
    throw 1; //@todo exception
  }
  pipe << msg << endl;
  pipe.close();

}

std::string Proxy::recv(){
  string result;
  ifstream pipe;
  pipe.open(in.c_str());
  cerr << "Opening " << in << " for input" << endl;
  if (!pipe) {
    cerr << "std::string Proxy::recv" << endl;
    throw 1; //@todo exception
  }
  string buffer;
  while (pipe >> buffer) {
    result += buffer + " " ;
    cerr << "buffer: " << buffer << endl;
    sleep(1);
  }
  pipe.close();
  return result;
}

Proxy::~Proxy(){

}

