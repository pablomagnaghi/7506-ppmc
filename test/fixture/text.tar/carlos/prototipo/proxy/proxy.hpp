#ifndef __proxy_hpp__
#define __proxy_hpp__

#include <iostream>
#include <fstream>
#include <cstring>

class Proxy {
public:
  Proxy(const std::string& in, const std::string& out);
  void send(const char* msg);
  std::string recv(); 
  ~Proxy();
private:
  std::string in;
  std::string out;
  Proxy(Proxy&);
  Proxy operator=(Proxy&);
};

#endif /* __proxy_hpp__ */

