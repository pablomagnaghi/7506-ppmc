#include "../events/eventhandler.hpp"
#include "../events/eventqueue.hpp"

#include "../events/kbmonitor.hpp"
#include "../events/pipemonitor.hpp"
//#include "../events/eventmonitor.hpp"

#include <cstdlib>

#include <iostream>
#include <string>


using namespace std;
using namespace events;
int main(int argc, char* argv[]) {
  EventQueue event_queue;

  EventMonitor event_monitor;
  EventHandler event_handler(event_monitor);

  string pipe_in_path(getenv("HOME"));
  string pipe_out_path(pipe_in_path);

  pipe_in_path +="/.catalogo/pipe_in"; //@todo hardcoded
  pipe_out_path += "/.catalogo/pipe_out"; //@todo hardcoded

  Proxy client(pipe_in_path, pipe_out_path);

  //pasar proxy a monitor


  PipeMonitor pipe(event_queue,client);

  KBMonitor keyboard(event_queue);

  keyboard.create();
  pipe.create();

  int end=0;
  int status=0;
  while (! end  ){
    cout << "consumer waiting" << endl;
    if( event_queue.mutex.trylock() ) {
      cout << "consumer handling" << endl;
      while(event_queue.size() && ! end) {
        end=! event_handler.handle(event_queue.getEvent());
        client.send(event_handler.response.c_str()); //@todo controlar esa conversion
        event_queue.closed=end;
      }
      status=event_queue.mutex.unlock();
      if (status != 0 ) throw 1; //@todo exception
    }
    sleep(1);
    cout << "consumer broadcasting" << endl;
  }
  cout << "consumer ending" << endl;
  return 0;
}
